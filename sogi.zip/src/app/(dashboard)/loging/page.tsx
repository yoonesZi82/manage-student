import React from "react";

function page() {
  return <div>page</div>;
}

export default page;
