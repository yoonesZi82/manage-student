
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Class
 * 
 */
export type Class = $Result.DefaultSelection<Prisma.$ClassPayload>
/**
 * Model SubClass
 * 
 */
export type SubClass = $Result.DefaultSelection<Prisma.$SubClassPayload>
/**
 * Model UserSubClass
 * 
 */
export type UserSubClass = $Result.DefaultSelection<Prisma.$UserSubClassPayload>
/**
 * Model PaidAmount
 * 
 */
export type PaidAmount = $Result.DefaultSelection<Prisma.$PaidAmountPayload>
/**
 * Model Admin
 * 
 */
export type Admin = $Result.DefaultSelection<Prisma.$AdminPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const PayStatus: {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
  PENDING: 'PENDING'
};

export type PayStatus = (typeof PayStatus)[keyof typeof PayStatus]


export const Day: {
  SATURDAY: 'SATURDAY',
  SUNDAY: 'SUNDAY',
  MONDAY: 'MONDAY',
  TUESDAY: 'TUESDAY',
  WEDNESDAY: 'WEDNESDAY',
  THURSDAY: 'THURSDAY',
  FRIDAY: 'FRIDAY'
};

export type Day = (typeof Day)[keyof typeof Day]


export const Role: {
  ADMIN: 'ADMIN'
};

export type Role = (typeof Role)[keyof typeof Role]

}

export type PayStatus = $Enums.PayStatus

export const PayStatus: typeof $Enums.PayStatus

export type Day = $Enums.Day

export const Day: typeof $Enums.Day

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P]): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number }): $Utils.JsPromise<R>

  /**
   * Executes a raw MongoDB command and returns the result of it.
   * @example
   * ```
   * const user = await prisma.$runCommandRaw({
   *   aggregate: 'User',
   *   pipeline: [{ $match: { name: 'Bob' } }, { $project: { email: true, _id: false } }],
   *   explain: false,
   * })
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $runCommandRaw(command: Prisma.InputJsonObject): Prisma.PrismaPromise<Prisma.JsonObject>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.class`: Exposes CRUD operations for the **Class** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Classes
    * const classes = await prisma.class.findMany()
    * ```
    */
  get class(): Prisma.ClassDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.subClass`: Exposes CRUD operations for the **SubClass** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more SubClasses
    * const subClasses = await prisma.subClass.findMany()
    * ```
    */
  get subClass(): Prisma.SubClassDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.userSubClass`: Exposes CRUD operations for the **UserSubClass** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more UserSubClasses
    * const userSubClasses = await prisma.userSubClass.findMany()
    * ```
    */
  get userSubClass(): Prisma.UserSubClassDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.paidAmount`: Exposes CRUD operations for the **PaidAmount** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PaidAmounts
    * const paidAmounts = await prisma.paidAmount.findMany()
    * ```
    */
  get paidAmount(): Prisma.PaidAmountDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.admin`: Exposes CRUD operations for the **Admin** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Admins
    * const admins = await prisma.admin.findMany()
    * ```
    */
  get admin(): Prisma.AdminDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.10.1
   * Query Engine version: 9b628578b3b7cae625e8c927178f15a170e74a9c
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Class: 'Class',
    SubClass: 'SubClass',
    UserSubClass: 'UserSubClass',
    PaidAmount: 'PaidAmount',
    Admin: 'Admin'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "class" | "subClass" | "userSubClass" | "paidAmount" | "admin"
      txIsolationLevel: never
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          findRaw: {
            args: Prisma.UserFindRawArgs<ExtArgs>
            result: JsonObject
          }
          aggregateRaw: {
            args: Prisma.UserAggregateRawArgs<ExtArgs>
            result: JsonObject
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Class: {
        payload: Prisma.$ClassPayload<ExtArgs>
        fields: Prisma.ClassFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ClassFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ClassFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>
          }
          findFirst: {
            args: Prisma.ClassFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ClassFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>
          }
          findMany: {
            args: Prisma.ClassFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>[]
          }
          create: {
            args: Prisma.ClassCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>
          }
          createMany: {
            args: Prisma.ClassCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.ClassDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>
          }
          update: {
            args: Prisma.ClassUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>
          }
          deleteMany: {
            args: Prisma.ClassDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ClassUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.ClassUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ClassPayload>
          }
          aggregate: {
            args: Prisma.ClassAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateClass>
          }
          groupBy: {
            args: Prisma.ClassGroupByArgs<ExtArgs>
            result: $Utils.Optional<ClassGroupByOutputType>[]
          }
          findRaw: {
            args: Prisma.ClassFindRawArgs<ExtArgs>
            result: JsonObject
          }
          aggregateRaw: {
            args: Prisma.ClassAggregateRawArgs<ExtArgs>
            result: JsonObject
          }
          count: {
            args: Prisma.ClassCountArgs<ExtArgs>
            result: $Utils.Optional<ClassCountAggregateOutputType> | number
          }
        }
      }
      SubClass: {
        payload: Prisma.$SubClassPayload<ExtArgs>
        fields: Prisma.SubClassFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SubClassFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SubClassFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>
          }
          findFirst: {
            args: Prisma.SubClassFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SubClassFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>
          }
          findMany: {
            args: Prisma.SubClassFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>[]
          }
          create: {
            args: Prisma.SubClassCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>
          }
          createMany: {
            args: Prisma.SubClassCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.SubClassDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>
          }
          update: {
            args: Prisma.SubClassUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>
          }
          deleteMany: {
            args: Prisma.SubClassDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SubClassUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.SubClassUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SubClassPayload>
          }
          aggregate: {
            args: Prisma.SubClassAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSubClass>
          }
          groupBy: {
            args: Prisma.SubClassGroupByArgs<ExtArgs>
            result: $Utils.Optional<SubClassGroupByOutputType>[]
          }
          findRaw: {
            args: Prisma.SubClassFindRawArgs<ExtArgs>
            result: JsonObject
          }
          aggregateRaw: {
            args: Prisma.SubClassAggregateRawArgs<ExtArgs>
            result: JsonObject
          }
          count: {
            args: Prisma.SubClassCountArgs<ExtArgs>
            result: $Utils.Optional<SubClassCountAggregateOutputType> | number
          }
        }
      }
      UserSubClass: {
        payload: Prisma.$UserSubClassPayload<ExtArgs>
        fields: Prisma.UserSubClassFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserSubClassFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserSubClassFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>
          }
          findFirst: {
            args: Prisma.UserSubClassFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserSubClassFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>
          }
          findMany: {
            args: Prisma.UserSubClassFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>[]
          }
          create: {
            args: Prisma.UserSubClassCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>
          }
          createMany: {
            args: Prisma.UserSubClassCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.UserSubClassDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>
          }
          update: {
            args: Prisma.UserSubClassUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>
          }
          deleteMany: {
            args: Prisma.UserSubClassDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserSubClassUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.UserSubClassUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserSubClassPayload>
          }
          aggregate: {
            args: Prisma.UserSubClassAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUserSubClass>
          }
          groupBy: {
            args: Prisma.UserSubClassGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserSubClassGroupByOutputType>[]
          }
          findRaw: {
            args: Prisma.UserSubClassFindRawArgs<ExtArgs>
            result: JsonObject
          }
          aggregateRaw: {
            args: Prisma.UserSubClassAggregateRawArgs<ExtArgs>
            result: JsonObject
          }
          count: {
            args: Prisma.UserSubClassCountArgs<ExtArgs>
            result: $Utils.Optional<UserSubClassCountAggregateOutputType> | number
          }
        }
      }
      PaidAmount: {
        payload: Prisma.$PaidAmountPayload<ExtArgs>
        fields: Prisma.PaidAmountFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PaidAmountFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PaidAmountFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>
          }
          findFirst: {
            args: Prisma.PaidAmountFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PaidAmountFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>
          }
          findMany: {
            args: Prisma.PaidAmountFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>[]
          }
          create: {
            args: Prisma.PaidAmountCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>
          }
          createMany: {
            args: Prisma.PaidAmountCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.PaidAmountDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>
          }
          update: {
            args: Prisma.PaidAmountUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>
          }
          deleteMany: {
            args: Prisma.PaidAmountDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PaidAmountUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.PaidAmountUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaidAmountPayload>
          }
          aggregate: {
            args: Prisma.PaidAmountAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePaidAmount>
          }
          groupBy: {
            args: Prisma.PaidAmountGroupByArgs<ExtArgs>
            result: $Utils.Optional<PaidAmountGroupByOutputType>[]
          }
          findRaw: {
            args: Prisma.PaidAmountFindRawArgs<ExtArgs>
            result: JsonObject
          }
          aggregateRaw: {
            args: Prisma.PaidAmountAggregateRawArgs<ExtArgs>
            result: JsonObject
          }
          count: {
            args: Prisma.PaidAmountCountArgs<ExtArgs>
            result: $Utils.Optional<PaidAmountCountAggregateOutputType> | number
          }
        }
      }
      Admin: {
        payload: Prisma.$AdminPayload<ExtArgs>
        fields: Prisma.AdminFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AdminFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AdminFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          findFirst: {
            args: Prisma.AdminFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AdminFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          findMany: {
            args: Prisma.AdminFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>[]
          }
          create: {
            args: Prisma.AdminCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          createMany: {
            args: Prisma.AdminCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.AdminDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          update: {
            args: Prisma.AdminUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          deleteMany: {
            args: Prisma.AdminDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AdminUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.AdminUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AdminPayload>
          }
          aggregate: {
            args: Prisma.AdminAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAdmin>
          }
          groupBy: {
            args: Prisma.AdminGroupByArgs<ExtArgs>
            result: $Utils.Optional<AdminGroupByOutputType>[]
          }
          findRaw: {
            args: Prisma.AdminFindRawArgs<ExtArgs>
            result: JsonObject
          }
          aggregateRaw: {
            args: Prisma.AdminAggregateRawArgs<ExtArgs>
            result: JsonObject
          }
          count: {
            args: Prisma.AdminCountArgs<ExtArgs>
            result: $Utils.Optional<AdminCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $runCommandRaw: {
          args: Prisma.InputJsonObject,
          result: Prisma.JsonObject
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    class?: ClassOmit
    subClass?: SubClassOmit
    userSubClass?: UserSubClassOmit
    paidAmount?: PaidAmountOmit
    admin?: AdminOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    paidAmounts: number
    userSubClasses: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    paidAmounts?: boolean | UserCountOutputTypeCountPaidAmountsArgs
    userSubClasses?: boolean | UserCountOutputTypeCountUserSubClassesArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountPaidAmountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaidAmountWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountUserSubClassesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserSubClassWhereInput
  }


  /**
   * Count Type ClassCountOutputType
   */

  export type ClassCountOutputType = {
    subClass: number
  }

  export type ClassCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    subClass?: boolean | ClassCountOutputTypeCountSubClassArgs
  }

  // Custom InputTypes
  /**
   * ClassCountOutputType without action
   */
  export type ClassCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ClassCountOutputType
     */
    select?: ClassCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * ClassCountOutputType without action
   */
  export type ClassCountOutputTypeCountSubClassArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SubClassWhereInput
  }


  /**
   * Count Type SubClassCountOutputType
   */

  export type SubClassCountOutputType = {
    userSubClasses: number
    paidAmounts: number
  }

  export type SubClassCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    userSubClasses?: boolean | SubClassCountOutputTypeCountUserSubClassesArgs
    paidAmounts?: boolean | SubClassCountOutputTypeCountPaidAmountsArgs
  }

  // Custom InputTypes
  /**
   * SubClassCountOutputType without action
   */
  export type SubClassCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClassCountOutputType
     */
    select?: SubClassCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * SubClassCountOutputType without action
   */
  export type SubClassCountOutputTypeCountUserSubClassesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserSubClassWhereInput
  }

  /**
   * SubClassCountOutputType without action
   */
  export type SubClassCountOutputTypeCountPaidAmountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaidAmountWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    nationalCode: string | null
    name: string | null
    phone: string | null
    motherName: string | null
    fatherName: string | null
    birthDate: Date | null
    gender: string | null
    address: string | null
    city: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    nationalCode: string | null
    name: string | null
    phone: string | null
    motherName: string | null
    fatherName: string | null
    birthDate: Date | null
    gender: string | null
    address: string | null
    city: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    nationalCode: number
    name: number
    phone: number
    motherName: number
    fatherName: number
    birthDate: number
    gender: number
    address: number
    city: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    nationalCode?: true
    name?: true
    phone?: true
    motherName?: true
    fatherName?: true
    birthDate?: true
    gender?: true
    address?: true
    city?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    nationalCode?: true
    name?: true
    phone?: true
    motherName?: true
    fatherName?: true
    birthDate?: true
    gender?: true
    address?: true
    city?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    nationalCode?: true
    name?: true
    phone?: true
    motherName?: true
    fatherName?: true
    birthDate?: true
    gender?: true
    address?: true
    city?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date
    gender: string
    address: string
    city: string
    createdAt: Date
    updatedAt: Date
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    nationalCode?: boolean
    name?: boolean
    phone?: boolean
    motherName?: boolean
    fatherName?: boolean
    birthDate?: boolean
    gender?: boolean
    address?: boolean
    city?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    paidAmounts?: boolean | User$paidAmountsArgs<ExtArgs>
    userSubClasses?: boolean | User$userSubClassesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>



  export type UserSelectScalar = {
    id?: boolean
    nationalCode?: boolean
    name?: boolean
    phone?: boolean
    motherName?: boolean
    fatherName?: boolean
    birthDate?: boolean
    gender?: boolean
    address?: boolean
    city?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "nationalCode" | "name" | "phone" | "motherName" | "fatherName" | "birthDate" | "gender" | "address" | "city" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    paidAmounts?: boolean | User$paidAmountsArgs<ExtArgs>
    userSubClasses?: boolean | User$userSubClassesArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      paidAmounts: Prisma.$PaidAmountPayload<ExtArgs>[]
      userSubClasses: Prisma.$UserSubClassPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      nationalCode: string
      name: string
      phone: string
      motherName: string
      fatherName: string
      birthDate: Date
      gender: string
      address: string
      city: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * @param {UserFindRawArgs} args - Select which filters you would like to apply.
     * @example
     * const user = await prisma.user.findRaw({
     *   filter: { age: { $gt: 25 } }
     * })
     */
    findRaw(args?: UserFindRawArgs): Prisma.PrismaPromise<JsonObject>

    /**
     * Perform aggregation operations on a User.
     * @param {UserAggregateRawArgs} args - Select which aggregations you would like to apply.
     * @example
     * const user = await prisma.user.aggregateRaw({
     *   pipeline: [
     *     { $match: { status: "registered" } },
     *     { $group: { _id: "$country", total: { $sum: 1 } } }
     *   ]
     * })
     */
    aggregateRaw(args?: UserAggregateRawArgs): Prisma.PrismaPromise<JsonObject>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    paidAmounts<T extends User$paidAmountsArgs<ExtArgs> = {}>(args?: Subset<T, User$paidAmountsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    userSubClasses<T extends User$userSubClassesArgs<ExtArgs> = {}>(args?: Subset<T, User$userSubClassesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly nationalCode: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly phone: FieldRef<"User", 'String'>
    readonly motherName: FieldRef<"User", 'String'>
    readonly fatherName: FieldRef<"User", 'String'>
    readonly birthDate: FieldRef<"User", 'DateTime'>
    readonly gender: FieldRef<"User", 'String'>
    readonly address: FieldRef<"User", 'String'>
    readonly city: FieldRef<"User", 'String'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User findRaw
   */
  export type UserFindRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The query predicate filter. If unspecified, then all documents in the collection will match the predicate. ${@link https://docs.mongodb.com/manual/reference/operator/query MongoDB Docs}.
     */
    filter?: InputJsonValue
    /**
     * Additional options to pass to the `find` command ${@link https://docs.mongodb.com/manual/reference/command/find/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * User aggregateRaw
   */
  export type UserAggregateRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * An array of aggregation stages to process and transform the document stream via the aggregation pipeline. ${@link https://docs.mongodb.com/manual/reference/operator/aggregation-pipeline MongoDB Docs}.
     */
    pipeline?: InputJsonValue[]
    /**
     * Additional options to pass to the `aggregate` command ${@link https://docs.mongodb.com/manual/reference/command/aggregate/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * User.paidAmounts
   */
  export type User$paidAmountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    where?: PaidAmountWhereInput
    orderBy?: PaidAmountOrderByWithRelationInput | PaidAmountOrderByWithRelationInput[]
    cursor?: PaidAmountWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaidAmountScalarFieldEnum | PaidAmountScalarFieldEnum[]
  }

  /**
   * User.userSubClasses
   */
  export type User$userSubClassesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    where?: UserSubClassWhereInput
    orderBy?: UserSubClassOrderByWithRelationInput | UserSubClassOrderByWithRelationInput[]
    cursor?: UserSubClassWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserSubClassScalarFieldEnum | UserSubClassScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Class
   */

  export type AggregateClass = {
    _count: ClassCountAggregateOutputType | null
    _avg: ClassAvgAggregateOutputType | null
    _sum: ClassSumAggregateOutputType | null
    _min: ClassMinAggregateOutputType | null
    _max: ClassMaxAggregateOutputType | null
  }

  export type ClassAvgAggregateOutputType = {
    subClassCount: number | null
  }

  export type ClassSumAggregateOutputType = {
    subClassCount: number | null
  }

  export type ClassMinAggregateOutputType = {
    id: string | null
    name: string | null
    subClassCount: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ClassMaxAggregateOutputType = {
    id: string | null
    name: string | null
    subClassCount: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type ClassCountAggregateOutputType = {
    id: number
    name: number
    subClassCount: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type ClassAvgAggregateInputType = {
    subClassCount?: true
  }

  export type ClassSumAggregateInputType = {
    subClassCount?: true
  }

  export type ClassMinAggregateInputType = {
    id?: true
    name?: true
    subClassCount?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ClassMaxAggregateInputType = {
    id?: true
    name?: true
    subClassCount?: true
    createdAt?: true
    updatedAt?: true
  }

  export type ClassCountAggregateInputType = {
    id?: true
    name?: true
    subClassCount?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type ClassAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Class to aggregate.
     */
    where?: ClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Classes to fetch.
     */
    orderBy?: ClassOrderByWithRelationInput | ClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Classes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Classes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Classes
    **/
    _count?: true | ClassCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: ClassAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: ClassSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ClassMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ClassMaxAggregateInputType
  }

  export type GetClassAggregateType<T extends ClassAggregateArgs> = {
        [P in keyof T & keyof AggregateClass]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateClass[P]>
      : GetScalarType<T[P], AggregateClass[P]>
  }




  export type ClassGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ClassWhereInput
    orderBy?: ClassOrderByWithAggregationInput | ClassOrderByWithAggregationInput[]
    by: ClassScalarFieldEnum[] | ClassScalarFieldEnum
    having?: ClassScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ClassCountAggregateInputType | true
    _avg?: ClassAvgAggregateInputType
    _sum?: ClassSumAggregateInputType
    _min?: ClassMinAggregateInputType
    _max?: ClassMaxAggregateInputType
  }

  export type ClassGroupByOutputType = {
    id: string
    name: string
    subClassCount: number
    createdAt: Date
    updatedAt: Date
    _count: ClassCountAggregateOutputType | null
    _avg: ClassAvgAggregateOutputType | null
    _sum: ClassSumAggregateOutputType | null
    _min: ClassMinAggregateOutputType | null
    _max: ClassMaxAggregateOutputType | null
  }

  type GetClassGroupByPayload<T extends ClassGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ClassGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ClassGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ClassGroupByOutputType[P]>
            : GetScalarType<T[P], ClassGroupByOutputType[P]>
        }
      >
    >


  export type ClassSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    subClassCount?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    subClass?: boolean | Class$subClassArgs<ExtArgs>
    _count?: boolean | ClassCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["class"]>



  export type ClassSelectScalar = {
    id?: boolean
    name?: boolean
    subClassCount?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type ClassOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "subClassCount" | "createdAt" | "updatedAt", ExtArgs["result"]["class"]>
  export type ClassInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    subClass?: boolean | Class$subClassArgs<ExtArgs>
    _count?: boolean | ClassCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $ClassPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Class"
    objects: {
      subClass: Prisma.$SubClassPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      subClassCount: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["class"]>
    composites: {}
  }

  type ClassGetPayload<S extends boolean | null | undefined | ClassDefaultArgs> = $Result.GetResult<Prisma.$ClassPayload, S>

  type ClassCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ClassFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ClassCountAggregateInputType | true
    }

  export interface ClassDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Class'], meta: { name: 'Class' } }
    /**
     * Find zero or one Class that matches the filter.
     * @param {ClassFindUniqueArgs} args - Arguments to find a Class
     * @example
     * // Get one Class
     * const class = await prisma.class.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ClassFindUniqueArgs>(args: SelectSubset<T, ClassFindUniqueArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Class that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ClassFindUniqueOrThrowArgs} args - Arguments to find a Class
     * @example
     * // Get one Class
     * const class = await prisma.class.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ClassFindUniqueOrThrowArgs>(args: SelectSubset<T, ClassFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Class that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassFindFirstArgs} args - Arguments to find a Class
     * @example
     * // Get one Class
     * const class = await prisma.class.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ClassFindFirstArgs>(args?: SelectSubset<T, ClassFindFirstArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Class that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassFindFirstOrThrowArgs} args - Arguments to find a Class
     * @example
     * // Get one Class
     * const class = await prisma.class.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ClassFindFirstOrThrowArgs>(args?: SelectSubset<T, ClassFindFirstOrThrowArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Classes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Classes
     * const classes = await prisma.class.findMany()
     * 
     * // Get first 10 Classes
     * const classes = await prisma.class.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const classWithIdOnly = await prisma.class.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ClassFindManyArgs>(args?: SelectSubset<T, ClassFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Class.
     * @param {ClassCreateArgs} args - Arguments to create a Class.
     * @example
     * // Create one Class
     * const Class = await prisma.class.create({
     *   data: {
     *     // ... data to create a Class
     *   }
     * })
     * 
     */
    create<T extends ClassCreateArgs>(args: SelectSubset<T, ClassCreateArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Classes.
     * @param {ClassCreateManyArgs} args - Arguments to create many Classes.
     * @example
     * // Create many Classes
     * const class = await prisma.class.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ClassCreateManyArgs>(args?: SelectSubset<T, ClassCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Class.
     * @param {ClassDeleteArgs} args - Arguments to delete one Class.
     * @example
     * // Delete one Class
     * const Class = await prisma.class.delete({
     *   where: {
     *     // ... filter to delete one Class
     *   }
     * })
     * 
     */
    delete<T extends ClassDeleteArgs>(args: SelectSubset<T, ClassDeleteArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Class.
     * @param {ClassUpdateArgs} args - Arguments to update one Class.
     * @example
     * // Update one Class
     * const class = await prisma.class.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ClassUpdateArgs>(args: SelectSubset<T, ClassUpdateArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Classes.
     * @param {ClassDeleteManyArgs} args - Arguments to filter Classes to delete.
     * @example
     * // Delete a few Classes
     * const { count } = await prisma.class.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ClassDeleteManyArgs>(args?: SelectSubset<T, ClassDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Classes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Classes
     * const class = await prisma.class.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ClassUpdateManyArgs>(args: SelectSubset<T, ClassUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Class.
     * @param {ClassUpsertArgs} args - Arguments to update or create a Class.
     * @example
     * // Update or create a Class
     * const class = await prisma.class.upsert({
     *   create: {
     *     // ... data to create a Class
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Class we want to update
     *   }
     * })
     */
    upsert<T extends ClassUpsertArgs>(args: SelectSubset<T, ClassUpsertArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Classes that matches the filter.
     * @param {ClassFindRawArgs} args - Select which filters you would like to apply.
     * @example
     * const class = await prisma.class.findRaw({
     *   filter: { age: { $gt: 25 } }
     * })
     */
    findRaw(args?: ClassFindRawArgs): Prisma.PrismaPromise<JsonObject>

    /**
     * Perform aggregation operations on a Class.
     * @param {ClassAggregateRawArgs} args - Select which aggregations you would like to apply.
     * @example
     * const class = await prisma.class.aggregateRaw({
     *   pipeline: [
     *     { $match: { status: "registered" } },
     *     { $group: { _id: "$country", total: { $sum: 1 } } }
     *   ]
     * })
     */
    aggregateRaw(args?: ClassAggregateRawArgs): Prisma.PrismaPromise<JsonObject>


    /**
     * Count the number of Classes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassCountArgs} args - Arguments to filter Classes to count.
     * @example
     * // Count the number of Classes
     * const count = await prisma.class.count({
     *   where: {
     *     // ... the filter for the Classes we want to count
     *   }
     * })
    **/
    count<T extends ClassCountArgs>(
      args?: Subset<T, ClassCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ClassCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Class.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ClassAggregateArgs>(args: Subset<T, ClassAggregateArgs>): Prisma.PrismaPromise<GetClassAggregateType<T>>

    /**
     * Group by Class.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ClassGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ClassGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ClassGroupByArgs['orderBy'] }
        : { orderBy?: ClassGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ClassGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetClassGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Class model
   */
  readonly fields: ClassFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Class.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ClassClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    subClass<T extends Class$subClassArgs<ExtArgs> = {}>(args?: Subset<T, Class$subClassArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Class model
   */
  interface ClassFieldRefs {
    readonly id: FieldRef<"Class", 'String'>
    readonly name: FieldRef<"Class", 'String'>
    readonly subClassCount: FieldRef<"Class", 'Int'>
    readonly createdAt: FieldRef<"Class", 'DateTime'>
    readonly updatedAt: FieldRef<"Class", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Class findUnique
   */
  export type ClassFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * Filter, which Class to fetch.
     */
    where: ClassWhereUniqueInput
  }

  /**
   * Class findUniqueOrThrow
   */
  export type ClassFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * Filter, which Class to fetch.
     */
    where: ClassWhereUniqueInput
  }

  /**
   * Class findFirst
   */
  export type ClassFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * Filter, which Class to fetch.
     */
    where?: ClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Classes to fetch.
     */
    orderBy?: ClassOrderByWithRelationInput | ClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Classes.
     */
    cursor?: ClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Classes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Classes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Classes.
     */
    distinct?: ClassScalarFieldEnum | ClassScalarFieldEnum[]
  }

  /**
   * Class findFirstOrThrow
   */
  export type ClassFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * Filter, which Class to fetch.
     */
    where?: ClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Classes to fetch.
     */
    orderBy?: ClassOrderByWithRelationInput | ClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Classes.
     */
    cursor?: ClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Classes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Classes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Classes.
     */
    distinct?: ClassScalarFieldEnum | ClassScalarFieldEnum[]
  }

  /**
   * Class findMany
   */
  export type ClassFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * Filter, which Classes to fetch.
     */
    where?: ClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Classes to fetch.
     */
    orderBy?: ClassOrderByWithRelationInput | ClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Classes.
     */
    cursor?: ClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Classes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Classes.
     */
    skip?: number
    distinct?: ClassScalarFieldEnum | ClassScalarFieldEnum[]
  }

  /**
   * Class create
   */
  export type ClassCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * The data needed to create a Class.
     */
    data: XOR<ClassCreateInput, ClassUncheckedCreateInput>
  }

  /**
   * Class createMany
   */
  export type ClassCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Classes.
     */
    data: ClassCreateManyInput | ClassCreateManyInput[]
  }

  /**
   * Class update
   */
  export type ClassUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * The data needed to update a Class.
     */
    data: XOR<ClassUpdateInput, ClassUncheckedUpdateInput>
    /**
     * Choose, which Class to update.
     */
    where: ClassWhereUniqueInput
  }

  /**
   * Class updateMany
   */
  export type ClassUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Classes.
     */
    data: XOR<ClassUpdateManyMutationInput, ClassUncheckedUpdateManyInput>
    /**
     * Filter which Classes to update
     */
    where?: ClassWhereInput
    /**
     * Limit how many Classes to update.
     */
    limit?: number
  }

  /**
   * Class upsert
   */
  export type ClassUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * The filter to search for the Class to update in case it exists.
     */
    where: ClassWhereUniqueInput
    /**
     * In case the Class found by the `where` argument doesn't exist, create a new Class with this data.
     */
    create: XOR<ClassCreateInput, ClassUncheckedCreateInput>
    /**
     * In case the Class was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ClassUpdateInput, ClassUncheckedUpdateInput>
  }

  /**
   * Class delete
   */
  export type ClassDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
    /**
     * Filter which Class to delete.
     */
    where: ClassWhereUniqueInput
  }

  /**
   * Class deleteMany
   */
  export type ClassDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Classes to delete
     */
    where?: ClassWhereInput
    /**
     * Limit how many Classes to delete.
     */
    limit?: number
  }

  /**
   * Class findRaw
   */
  export type ClassFindRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The query predicate filter. If unspecified, then all documents in the collection will match the predicate. ${@link https://docs.mongodb.com/manual/reference/operator/query MongoDB Docs}.
     */
    filter?: InputJsonValue
    /**
     * Additional options to pass to the `find` command ${@link https://docs.mongodb.com/manual/reference/command/find/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * Class aggregateRaw
   */
  export type ClassAggregateRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * An array of aggregation stages to process and transform the document stream via the aggregation pipeline. ${@link https://docs.mongodb.com/manual/reference/operator/aggregation-pipeline MongoDB Docs}.
     */
    pipeline?: InputJsonValue[]
    /**
     * Additional options to pass to the `aggregate` command ${@link https://docs.mongodb.com/manual/reference/command/aggregate/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * Class.subClass
   */
  export type Class$subClassArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    where?: SubClassWhereInput
    orderBy?: SubClassOrderByWithRelationInput | SubClassOrderByWithRelationInput[]
    cursor?: SubClassWhereUniqueInput
    take?: number
    skip?: number
    distinct?: SubClassScalarFieldEnum | SubClassScalarFieldEnum[]
  }

  /**
   * Class without action
   */
  export type ClassDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Class
     */
    select?: ClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Class
     */
    omit?: ClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ClassInclude<ExtArgs> | null
  }


  /**
   * Model SubClass
   */

  export type AggregateSubClass = {
    _count: SubClassCountAggregateOutputType | null
    _avg: SubClassAvgAggregateOutputType | null
    _sum: SubClassSumAggregateOutputType | null
    _min: SubClassMinAggregateOutputType | null
    _max: SubClassMaxAggregateOutputType | null
  }

  export type SubClassAvgAggregateOutputType = {
    totalAmount: number | null
  }

  export type SubClassSumAggregateOutputType = {
    totalAmount: number | null
  }

  export type SubClassMinAggregateOutputType = {
    id: string | null
    classId: string | null
    name: string | null
    totalAmount: number | null
    teacher: string | null
    day: $Enums.Day | null
    startTime: string | null
    endTime: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SubClassMaxAggregateOutputType = {
    id: string | null
    classId: string | null
    name: string | null
    totalAmount: number | null
    teacher: string | null
    day: $Enums.Day | null
    startTime: string | null
    endTime: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SubClassCountAggregateOutputType = {
    id: number
    classId: number
    name: number
    totalAmount: number
    teacher: number
    day: number
    startTime: number
    endTime: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SubClassAvgAggregateInputType = {
    totalAmount?: true
  }

  export type SubClassSumAggregateInputType = {
    totalAmount?: true
  }

  export type SubClassMinAggregateInputType = {
    id?: true
    classId?: true
    name?: true
    totalAmount?: true
    teacher?: true
    day?: true
    startTime?: true
    endTime?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SubClassMaxAggregateInputType = {
    id?: true
    classId?: true
    name?: true
    totalAmount?: true
    teacher?: true
    day?: true
    startTime?: true
    endTime?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SubClassCountAggregateInputType = {
    id?: true
    classId?: true
    name?: true
    totalAmount?: true
    teacher?: true
    day?: true
    startTime?: true
    endTime?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SubClassAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SubClass to aggregate.
     */
    where?: SubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SubClasses to fetch.
     */
    orderBy?: SubClassOrderByWithRelationInput | SubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SubClasses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned SubClasses
    **/
    _count?: true | SubClassCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SubClassAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SubClassSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SubClassMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SubClassMaxAggregateInputType
  }

  export type GetSubClassAggregateType<T extends SubClassAggregateArgs> = {
        [P in keyof T & keyof AggregateSubClass]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSubClass[P]>
      : GetScalarType<T[P], AggregateSubClass[P]>
  }




  export type SubClassGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SubClassWhereInput
    orderBy?: SubClassOrderByWithAggregationInput | SubClassOrderByWithAggregationInput[]
    by: SubClassScalarFieldEnum[] | SubClassScalarFieldEnum
    having?: SubClassScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SubClassCountAggregateInputType | true
    _avg?: SubClassAvgAggregateInputType
    _sum?: SubClassSumAggregateInputType
    _min?: SubClassMinAggregateInputType
    _max?: SubClassMaxAggregateInputType
  }

  export type SubClassGroupByOutputType = {
    id: string
    classId: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt: Date
    updatedAt: Date
    _count: SubClassCountAggregateOutputType | null
    _avg: SubClassAvgAggregateOutputType | null
    _sum: SubClassSumAggregateOutputType | null
    _min: SubClassMinAggregateOutputType | null
    _max: SubClassMaxAggregateOutputType | null
  }

  type GetSubClassGroupByPayload<T extends SubClassGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SubClassGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SubClassGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SubClassGroupByOutputType[P]>
            : GetScalarType<T[P], SubClassGroupByOutputType[P]>
        }
      >
    >


  export type SubClassSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    classId?: boolean
    name?: boolean
    totalAmount?: boolean
    teacher?: boolean
    day?: boolean
    startTime?: boolean
    endTime?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    class?: boolean | ClassDefaultArgs<ExtArgs>
    userSubClasses?: boolean | SubClass$userSubClassesArgs<ExtArgs>
    paidAmounts?: boolean | SubClass$paidAmountsArgs<ExtArgs>
    _count?: boolean | SubClassCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["subClass"]>



  export type SubClassSelectScalar = {
    id?: boolean
    classId?: boolean
    name?: boolean
    totalAmount?: boolean
    teacher?: boolean
    day?: boolean
    startTime?: boolean
    endTime?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SubClassOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "classId" | "name" | "totalAmount" | "teacher" | "day" | "startTime" | "endTime" | "createdAt" | "updatedAt", ExtArgs["result"]["subClass"]>
  export type SubClassInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    class?: boolean | ClassDefaultArgs<ExtArgs>
    userSubClasses?: boolean | SubClass$userSubClassesArgs<ExtArgs>
    paidAmounts?: boolean | SubClass$paidAmountsArgs<ExtArgs>
    _count?: boolean | SubClassCountOutputTypeDefaultArgs<ExtArgs>
  }

  export type $SubClassPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "SubClass"
    objects: {
      class: Prisma.$ClassPayload<ExtArgs>
      userSubClasses: Prisma.$UserSubClassPayload<ExtArgs>[]
      paidAmounts: Prisma.$PaidAmountPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      classId: string
      name: string
      totalAmount: number
      teacher: string
      day: $Enums.Day
      startTime: string
      endTime: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["subClass"]>
    composites: {}
  }

  type SubClassGetPayload<S extends boolean | null | undefined | SubClassDefaultArgs> = $Result.GetResult<Prisma.$SubClassPayload, S>

  type SubClassCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SubClassFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SubClassCountAggregateInputType | true
    }

  export interface SubClassDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['SubClass'], meta: { name: 'SubClass' } }
    /**
     * Find zero or one SubClass that matches the filter.
     * @param {SubClassFindUniqueArgs} args - Arguments to find a SubClass
     * @example
     * // Get one SubClass
     * const subClass = await prisma.subClass.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SubClassFindUniqueArgs>(args: SelectSubset<T, SubClassFindUniqueArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one SubClass that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SubClassFindUniqueOrThrowArgs} args - Arguments to find a SubClass
     * @example
     * // Get one SubClass
     * const subClass = await prisma.subClass.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SubClassFindUniqueOrThrowArgs>(args: SelectSubset<T, SubClassFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SubClass that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassFindFirstArgs} args - Arguments to find a SubClass
     * @example
     * // Get one SubClass
     * const subClass = await prisma.subClass.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SubClassFindFirstArgs>(args?: SelectSubset<T, SubClassFindFirstArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first SubClass that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassFindFirstOrThrowArgs} args - Arguments to find a SubClass
     * @example
     * // Get one SubClass
     * const subClass = await prisma.subClass.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SubClassFindFirstOrThrowArgs>(args?: SelectSubset<T, SubClassFindFirstOrThrowArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SubClasses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all SubClasses
     * const subClasses = await prisma.subClass.findMany()
     * 
     * // Get first 10 SubClasses
     * const subClasses = await prisma.subClass.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const subClassWithIdOnly = await prisma.subClass.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SubClassFindManyArgs>(args?: SelectSubset<T, SubClassFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a SubClass.
     * @param {SubClassCreateArgs} args - Arguments to create a SubClass.
     * @example
     * // Create one SubClass
     * const SubClass = await prisma.subClass.create({
     *   data: {
     *     // ... data to create a SubClass
     *   }
     * })
     * 
     */
    create<T extends SubClassCreateArgs>(args: SelectSubset<T, SubClassCreateArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many SubClasses.
     * @param {SubClassCreateManyArgs} args - Arguments to create many SubClasses.
     * @example
     * // Create many SubClasses
     * const subClass = await prisma.subClass.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SubClassCreateManyArgs>(args?: SelectSubset<T, SubClassCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a SubClass.
     * @param {SubClassDeleteArgs} args - Arguments to delete one SubClass.
     * @example
     * // Delete one SubClass
     * const SubClass = await prisma.subClass.delete({
     *   where: {
     *     // ... filter to delete one SubClass
     *   }
     * })
     * 
     */
    delete<T extends SubClassDeleteArgs>(args: SelectSubset<T, SubClassDeleteArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one SubClass.
     * @param {SubClassUpdateArgs} args - Arguments to update one SubClass.
     * @example
     * // Update one SubClass
     * const subClass = await prisma.subClass.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SubClassUpdateArgs>(args: SelectSubset<T, SubClassUpdateArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more SubClasses.
     * @param {SubClassDeleteManyArgs} args - Arguments to filter SubClasses to delete.
     * @example
     * // Delete a few SubClasses
     * const { count } = await prisma.subClass.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SubClassDeleteManyArgs>(args?: SelectSubset<T, SubClassDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more SubClasses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many SubClasses
     * const subClass = await prisma.subClass.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SubClassUpdateManyArgs>(args: SelectSubset<T, SubClassUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one SubClass.
     * @param {SubClassUpsertArgs} args - Arguments to update or create a SubClass.
     * @example
     * // Update or create a SubClass
     * const subClass = await prisma.subClass.upsert({
     *   create: {
     *     // ... data to create a SubClass
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the SubClass we want to update
     *   }
     * })
     */
    upsert<T extends SubClassUpsertArgs>(args: SelectSubset<T, SubClassUpsertArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more SubClasses that matches the filter.
     * @param {SubClassFindRawArgs} args - Select which filters you would like to apply.
     * @example
     * const subClass = await prisma.subClass.findRaw({
     *   filter: { age: { $gt: 25 } }
     * })
     */
    findRaw(args?: SubClassFindRawArgs): Prisma.PrismaPromise<JsonObject>

    /**
     * Perform aggregation operations on a SubClass.
     * @param {SubClassAggregateRawArgs} args - Select which aggregations you would like to apply.
     * @example
     * const subClass = await prisma.subClass.aggregateRaw({
     *   pipeline: [
     *     { $match: { status: "registered" } },
     *     { $group: { _id: "$country", total: { $sum: 1 } } }
     *   ]
     * })
     */
    aggregateRaw(args?: SubClassAggregateRawArgs): Prisma.PrismaPromise<JsonObject>


    /**
     * Count the number of SubClasses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassCountArgs} args - Arguments to filter SubClasses to count.
     * @example
     * // Count the number of SubClasses
     * const count = await prisma.subClass.count({
     *   where: {
     *     // ... the filter for the SubClasses we want to count
     *   }
     * })
    **/
    count<T extends SubClassCountArgs>(
      args?: Subset<T, SubClassCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SubClassCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a SubClass.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SubClassAggregateArgs>(args: Subset<T, SubClassAggregateArgs>): Prisma.PrismaPromise<GetSubClassAggregateType<T>>

    /**
     * Group by SubClass.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SubClassGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SubClassGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SubClassGroupByArgs['orderBy'] }
        : { orderBy?: SubClassGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SubClassGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSubClassGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the SubClass model
   */
  readonly fields: SubClassFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for SubClass.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SubClassClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    class<T extends ClassDefaultArgs<ExtArgs> = {}>(args?: Subset<T, ClassDefaultArgs<ExtArgs>>): Prisma__ClassClient<$Result.GetResult<Prisma.$ClassPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    userSubClasses<T extends SubClass$userSubClassesArgs<ExtArgs> = {}>(args?: Subset<T, SubClass$userSubClassesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    paidAmounts<T extends SubClass$paidAmountsArgs<ExtArgs> = {}>(args?: Subset<T, SubClass$paidAmountsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the SubClass model
   */
  interface SubClassFieldRefs {
    readonly id: FieldRef<"SubClass", 'String'>
    readonly classId: FieldRef<"SubClass", 'String'>
    readonly name: FieldRef<"SubClass", 'String'>
    readonly totalAmount: FieldRef<"SubClass", 'Int'>
    readonly teacher: FieldRef<"SubClass", 'String'>
    readonly day: FieldRef<"SubClass", 'Day'>
    readonly startTime: FieldRef<"SubClass", 'String'>
    readonly endTime: FieldRef<"SubClass", 'String'>
    readonly createdAt: FieldRef<"SubClass", 'DateTime'>
    readonly updatedAt: FieldRef<"SubClass", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * SubClass findUnique
   */
  export type SubClassFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * Filter, which SubClass to fetch.
     */
    where: SubClassWhereUniqueInput
  }

  /**
   * SubClass findUniqueOrThrow
   */
  export type SubClassFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * Filter, which SubClass to fetch.
     */
    where: SubClassWhereUniqueInput
  }

  /**
   * SubClass findFirst
   */
  export type SubClassFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * Filter, which SubClass to fetch.
     */
    where?: SubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SubClasses to fetch.
     */
    orderBy?: SubClassOrderByWithRelationInput | SubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SubClasses.
     */
    cursor?: SubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SubClasses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SubClasses.
     */
    distinct?: SubClassScalarFieldEnum | SubClassScalarFieldEnum[]
  }

  /**
   * SubClass findFirstOrThrow
   */
  export type SubClassFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * Filter, which SubClass to fetch.
     */
    where?: SubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SubClasses to fetch.
     */
    orderBy?: SubClassOrderByWithRelationInput | SubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for SubClasses.
     */
    cursor?: SubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SubClasses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of SubClasses.
     */
    distinct?: SubClassScalarFieldEnum | SubClassScalarFieldEnum[]
  }

  /**
   * SubClass findMany
   */
  export type SubClassFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * Filter, which SubClasses to fetch.
     */
    where?: SubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of SubClasses to fetch.
     */
    orderBy?: SubClassOrderByWithRelationInput | SubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing SubClasses.
     */
    cursor?: SubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` SubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` SubClasses.
     */
    skip?: number
    distinct?: SubClassScalarFieldEnum | SubClassScalarFieldEnum[]
  }

  /**
   * SubClass create
   */
  export type SubClassCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * The data needed to create a SubClass.
     */
    data: XOR<SubClassCreateInput, SubClassUncheckedCreateInput>
  }

  /**
   * SubClass createMany
   */
  export type SubClassCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many SubClasses.
     */
    data: SubClassCreateManyInput | SubClassCreateManyInput[]
  }

  /**
   * SubClass update
   */
  export type SubClassUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * The data needed to update a SubClass.
     */
    data: XOR<SubClassUpdateInput, SubClassUncheckedUpdateInput>
    /**
     * Choose, which SubClass to update.
     */
    where: SubClassWhereUniqueInput
  }

  /**
   * SubClass updateMany
   */
  export type SubClassUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update SubClasses.
     */
    data: XOR<SubClassUpdateManyMutationInput, SubClassUncheckedUpdateManyInput>
    /**
     * Filter which SubClasses to update
     */
    where?: SubClassWhereInput
    /**
     * Limit how many SubClasses to update.
     */
    limit?: number
  }

  /**
   * SubClass upsert
   */
  export type SubClassUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * The filter to search for the SubClass to update in case it exists.
     */
    where: SubClassWhereUniqueInput
    /**
     * In case the SubClass found by the `where` argument doesn't exist, create a new SubClass with this data.
     */
    create: XOR<SubClassCreateInput, SubClassUncheckedCreateInput>
    /**
     * In case the SubClass was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SubClassUpdateInput, SubClassUncheckedUpdateInput>
  }

  /**
   * SubClass delete
   */
  export type SubClassDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
    /**
     * Filter which SubClass to delete.
     */
    where: SubClassWhereUniqueInput
  }

  /**
   * SubClass deleteMany
   */
  export type SubClassDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which SubClasses to delete
     */
    where?: SubClassWhereInput
    /**
     * Limit how many SubClasses to delete.
     */
    limit?: number
  }

  /**
   * SubClass findRaw
   */
  export type SubClassFindRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The query predicate filter. If unspecified, then all documents in the collection will match the predicate. ${@link https://docs.mongodb.com/manual/reference/operator/query MongoDB Docs}.
     */
    filter?: InputJsonValue
    /**
     * Additional options to pass to the `find` command ${@link https://docs.mongodb.com/manual/reference/command/find/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * SubClass aggregateRaw
   */
  export type SubClassAggregateRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * An array of aggregation stages to process and transform the document stream via the aggregation pipeline. ${@link https://docs.mongodb.com/manual/reference/operator/aggregation-pipeline MongoDB Docs}.
     */
    pipeline?: InputJsonValue[]
    /**
     * Additional options to pass to the `aggregate` command ${@link https://docs.mongodb.com/manual/reference/command/aggregate/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * SubClass.userSubClasses
   */
  export type SubClass$userSubClassesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    where?: UserSubClassWhereInput
    orderBy?: UserSubClassOrderByWithRelationInput | UserSubClassOrderByWithRelationInput[]
    cursor?: UserSubClassWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UserSubClassScalarFieldEnum | UserSubClassScalarFieldEnum[]
  }

  /**
   * SubClass.paidAmounts
   */
  export type SubClass$paidAmountsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    where?: PaidAmountWhereInput
    orderBy?: PaidAmountOrderByWithRelationInput | PaidAmountOrderByWithRelationInput[]
    cursor?: PaidAmountWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaidAmountScalarFieldEnum | PaidAmountScalarFieldEnum[]
  }

  /**
   * SubClass without action
   */
  export type SubClassDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the SubClass
     */
    select?: SubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the SubClass
     */
    omit?: SubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SubClassInclude<ExtArgs> | null
  }


  /**
   * Model UserSubClass
   */

  export type AggregateUserSubClass = {
    _count: UserSubClassCountAggregateOutputType | null
    _min: UserSubClassMinAggregateOutputType | null
    _max: UserSubClassMaxAggregateOutputType | null
  }

  export type UserSubClassMinAggregateOutputType = {
    id: string | null
    userId: string | null
    subClassId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserSubClassMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    subClassId: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserSubClassCountAggregateOutputType = {
    id: number
    userId: number
    subClassId: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserSubClassMinAggregateInputType = {
    id?: true
    userId?: true
    subClassId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserSubClassMaxAggregateInputType = {
    id?: true
    userId?: true
    subClassId?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserSubClassCountAggregateInputType = {
    id?: true
    userId?: true
    subClassId?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserSubClassAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserSubClass to aggregate.
     */
    where?: UserSubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserSubClasses to fetch.
     */
    orderBy?: UserSubClassOrderByWithRelationInput | UserSubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserSubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserSubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserSubClasses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned UserSubClasses
    **/
    _count?: true | UserSubClassCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserSubClassMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserSubClassMaxAggregateInputType
  }

  export type GetUserSubClassAggregateType<T extends UserSubClassAggregateArgs> = {
        [P in keyof T & keyof AggregateUserSubClass]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUserSubClass[P]>
      : GetScalarType<T[P], AggregateUserSubClass[P]>
  }




  export type UserSubClassGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserSubClassWhereInput
    orderBy?: UserSubClassOrderByWithAggregationInput | UserSubClassOrderByWithAggregationInput[]
    by: UserSubClassScalarFieldEnum[] | UserSubClassScalarFieldEnum
    having?: UserSubClassScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserSubClassCountAggregateInputType | true
    _min?: UserSubClassMinAggregateInputType
    _max?: UserSubClassMaxAggregateInputType
  }

  export type UserSubClassGroupByOutputType = {
    id: string
    userId: string
    subClassId: string
    createdAt: Date
    updatedAt: Date
    _count: UserSubClassCountAggregateOutputType | null
    _min: UserSubClassMinAggregateOutputType | null
    _max: UserSubClassMaxAggregateOutputType | null
  }

  type GetUserSubClassGroupByPayload<T extends UserSubClassGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserSubClassGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserSubClassGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserSubClassGroupByOutputType[P]>
            : GetScalarType<T[P], UserSubClassGroupByOutputType[P]>
        }
      >
    >


  export type UserSubClassSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    subClassId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    subClass?: boolean | SubClassDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["userSubClass"]>



  export type UserSubClassSelectScalar = {
    id?: boolean
    userId?: boolean
    subClassId?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserSubClassOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "subClassId" | "createdAt" | "updatedAt", ExtArgs["result"]["userSubClass"]>
  export type UserSubClassInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    subClass?: boolean | SubClassDefaultArgs<ExtArgs>
  }

  export type $UserSubClassPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "UserSubClass"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      subClass: Prisma.$SubClassPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      subClassId: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["userSubClass"]>
    composites: {}
  }

  type UserSubClassGetPayload<S extends boolean | null | undefined | UserSubClassDefaultArgs> = $Result.GetResult<Prisma.$UserSubClassPayload, S>

  type UserSubClassCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserSubClassFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserSubClassCountAggregateInputType | true
    }

  export interface UserSubClassDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['UserSubClass'], meta: { name: 'UserSubClass' } }
    /**
     * Find zero or one UserSubClass that matches the filter.
     * @param {UserSubClassFindUniqueArgs} args - Arguments to find a UserSubClass
     * @example
     * // Get one UserSubClass
     * const userSubClass = await prisma.userSubClass.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserSubClassFindUniqueArgs>(args: SelectSubset<T, UserSubClassFindUniqueArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one UserSubClass that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserSubClassFindUniqueOrThrowArgs} args - Arguments to find a UserSubClass
     * @example
     * // Get one UserSubClass
     * const userSubClass = await prisma.userSubClass.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserSubClassFindUniqueOrThrowArgs>(args: SelectSubset<T, UserSubClassFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserSubClass that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassFindFirstArgs} args - Arguments to find a UserSubClass
     * @example
     * // Get one UserSubClass
     * const userSubClass = await prisma.userSubClass.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserSubClassFindFirstArgs>(args?: SelectSubset<T, UserSubClassFindFirstArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first UserSubClass that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassFindFirstOrThrowArgs} args - Arguments to find a UserSubClass
     * @example
     * // Get one UserSubClass
     * const userSubClass = await prisma.userSubClass.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserSubClassFindFirstOrThrowArgs>(args?: SelectSubset<T, UserSubClassFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more UserSubClasses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all UserSubClasses
     * const userSubClasses = await prisma.userSubClass.findMany()
     * 
     * // Get first 10 UserSubClasses
     * const userSubClasses = await prisma.userSubClass.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userSubClassWithIdOnly = await prisma.userSubClass.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserSubClassFindManyArgs>(args?: SelectSubset<T, UserSubClassFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a UserSubClass.
     * @param {UserSubClassCreateArgs} args - Arguments to create a UserSubClass.
     * @example
     * // Create one UserSubClass
     * const UserSubClass = await prisma.userSubClass.create({
     *   data: {
     *     // ... data to create a UserSubClass
     *   }
     * })
     * 
     */
    create<T extends UserSubClassCreateArgs>(args: SelectSubset<T, UserSubClassCreateArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many UserSubClasses.
     * @param {UserSubClassCreateManyArgs} args - Arguments to create many UserSubClasses.
     * @example
     * // Create many UserSubClasses
     * const userSubClass = await prisma.userSubClass.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserSubClassCreateManyArgs>(args?: SelectSubset<T, UserSubClassCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a UserSubClass.
     * @param {UserSubClassDeleteArgs} args - Arguments to delete one UserSubClass.
     * @example
     * // Delete one UserSubClass
     * const UserSubClass = await prisma.userSubClass.delete({
     *   where: {
     *     // ... filter to delete one UserSubClass
     *   }
     * })
     * 
     */
    delete<T extends UserSubClassDeleteArgs>(args: SelectSubset<T, UserSubClassDeleteArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one UserSubClass.
     * @param {UserSubClassUpdateArgs} args - Arguments to update one UserSubClass.
     * @example
     * // Update one UserSubClass
     * const userSubClass = await prisma.userSubClass.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserSubClassUpdateArgs>(args: SelectSubset<T, UserSubClassUpdateArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more UserSubClasses.
     * @param {UserSubClassDeleteManyArgs} args - Arguments to filter UserSubClasses to delete.
     * @example
     * // Delete a few UserSubClasses
     * const { count } = await prisma.userSubClass.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserSubClassDeleteManyArgs>(args?: SelectSubset<T, UserSubClassDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more UserSubClasses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many UserSubClasses
     * const userSubClass = await prisma.userSubClass.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserSubClassUpdateManyArgs>(args: SelectSubset<T, UserSubClassUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one UserSubClass.
     * @param {UserSubClassUpsertArgs} args - Arguments to update or create a UserSubClass.
     * @example
     * // Update or create a UserSubClass
     * const userSubClass = await prisma.userSubClass.upsert({
     *   create: {
     *     // ... data to create a UserSubClass
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the UserSubClass we want to update
     *   }
     * })
     */
    upsert<T extends UserSubClassUpsertArgs>(args: SelectSubset<T, UserSubClassUpsertArgs<ExtArgs>>): Prisma__UserSubClassClient<$Result.GetResult<Prisma.$UserSubClassPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more UserSubClasses that matches the filter.
     * @param {UserSubClassFindRawArgs} args - Select which filters you would like to apply.
     * @example
     * const userSubClass = await prisma.userSubClass.findRaw({
     *   filter: { age: { $gt: 25 } }
     * })
     */
    findRaw(args?: UserSubClassFindRawArgs): Prisma.PrismaPromise<JsonObject>

    /**
     * Perform aggregation operations on a UserSubClass.
     * @param {UserSubClassAggregateRawArgs} args - Select which aggregations you would like to apply.
     * @example
     * const userSubClass = await prisma.userSubClass.aggregateRaw({
     *   pipeline: [
     *     { $match: { status: "registered" } },
     *     { $group: { _id: "$country", total: { $sum: 1 } } }
     *   ]
     * })
     */
    aggregateRaw(args?: UserSubClassAggregateRawArgs): Prisma.PrismaPromise<JsonObject>


    /**
     * Count the number of UserSubClasses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassCountArgs} args - Arguments to filter UserSubClasses to count.
     * @example
     * // Count the number of UserSubClasses
     * const count = await prisma.userSubClass.count({
     *   where: {
     *     // ... the filter for the UserSubClasses we want to count
     *   }
     * })
    **/
    count<T extends UserSubClassCountArgs>(
      args?: Subset<T, UserSubClassCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserSubClassCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a UserSubClass.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserSubClassAggregateArgs>(args: Subset<T, UserSubClassAggregateArgs>): Prisma.PrismaPromise<GetUserSubClassAggregateType<T>>

    /**
     * Group by UserSubClass.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserSubClassGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserSubClassGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserSubClassGroupByArgs['orderBy'] }
        : { orderBy?: UserSubClassGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserSubClassGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserSubClassGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the UserSubClass model
   */
  readonly fields: UserSubClassFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for UserSubClass.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserSubClassClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    subClass<T extends SubClassDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SubClassDefaultArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the UserSubClass model
   */
  interface UserSubClassFieldRefs {
    readonly id: FieldRef<"UserSubClass", 'String'>
    readonly userId: FieldRef<"UserSubClass", 'String'>
    readonly subClassId: FieldRef<"UserSubClass", 'String'>
    readonly createdAt: FieldRef<"UserSubClass", 'DateTime'>
    readonly updatedAt: FieldRef<"UserSubClass", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * UserSubClass findUnique
   */
  export type UserSubClassFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * Filter, which UserSubClass to fetch.
     */
    where: UserSubClassWhereUniqueInput
  }

  /**
   * UserSubClass findUniqueOrThrow
   */
  export type UserSubClassFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * Filter, which UserSubClass to fetch.
     */
    where: UserSubClassWhereUniqueInput
  }

  /**
   * UserSubClass findFirst
   */
  export type UserSubClassFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * Filter, which UserSubClass to fetch.
     */
    where?: UserSubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserSubClasses to fetch.
     */
    orderBy?: UserSubClassOrderByWithRelationInput | UserSubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserSubClasses.
     */
    cursor?: UserSubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserSubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserSubClasses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserSubClasses.
     */
    distinct?: UserSubClassScalarFieldEnum | UserSubClassScalarFieldEnum[]
  }

  /**
   * UserSubClass findFirstOrThrow
   */
  export type UserSubClassFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * Filter, which UserSubClass to fetch.
     */
    where?: UserSubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserSubClasses to fetch.
     */
    orderBy?: UserSubClassOrderByWithRelationInput | UserSubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for UserSubClasses.
     */
    cursor?: UserSubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserSubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserSubClasses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of UserSubClasses.
     */
    distinct?: UserSubClassScalarFieldEnum | UserSubClassScalarFieldEnum[]
  }

  /**
   * UserSubClass findMany
   */
  export type UserSubClassFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * Filter, which UserSubClasses to fetch.
     */
    where?: UserSubClassWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of UserSubClasses to fetch.
     */
    orderBy?: UserSubClassOrderByWithRelationInput | UserSubClassOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing UserSubClasses.
     */
    cursor?: UserSubClassWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` UserSubClasses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` UserSubClasses.
     */
    skip?: number
    distinct?: UserSubClassScalarFieldEnum | UserSubClassScalarFieldEnum[]
  }

  /**
   * UserSubClass create
   */
  export type UserSubClassCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * The data needed to create a UserSubClass.
     */
    data: XOR<UserSubClassCreateInput, UserSubClassUncheckedCreateInput>
  }

  /**
   * UserSubClass createMany
   */
  export type UserSubClassCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many UserSubClasses.
     */
    data: UserSubClassCreateManyInput | UserSubClassCreateManyInput[]
  }

  /**
   * UserSubClass update
   */
  export type UserSubClassUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * The data needed to update a UserSubClass.
     */
    data: XOR<UserSubClassUpdateInput, UserSubClassUncheckedUpdateInput>
    /**
     * Choose, which UserSubClass to update.
     */
    where: UserSubClassWhereUniqueInput
  }

  /**
   * UserSubClass updateMany
   */
  export type UserSubClassUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update UserSubClasses.
     */
    data: XOR<UserSubClassUpdateManyMutationInput, UserSubClassUncheckedUpdateManyInput>
    /**
     * Filter which UserSubClasses to update
     */
    where?: UserSubClassWhereInput
    /**
     * Limit how many UserSubClasses to update.
     */
    limit?: number
  }

  /**
   * UserSubClass upsert
   */
  export type UserSubClassUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * The filter to search for the UserSubClass to update in case it exists.
     */
    where: UserSubClassWhereUniqueInput
    /**
     * In case the UserSubClass found by the `where` argument doesn't exist, create a new UserSubClass with this data.
     */
    create: XOR<UserSubClassCreateInput, UserSubClassUncheckedCreateInput>
    /**
     * In case the UserSubClass was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserSubClassUpdateInput, UserSubClassUncheckedUpdateInput>
  }

  /**
   * UserSubClass delete
   */
  export type UserSubClassDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
    /**
     * Filter which UserSubClass to delete.
     */
    where: UserSubClassWhereUniqueInput
  }

  /**
   * UserSubClass deleteMany
   */
  export type UserSubClassDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which UserSubClasses to delete
     */
    where?: UserSubClassWhereInput
    /**
     * Limit how many UserSubClasses to delete.
     */
    limit?: number
  }

  /**
   * UserSubClass findRaw
   */
  export type UserSubClassFindRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The query predicate filter. If unspecified, then all documents in the collection will match the predicate. ${@link https://docs.mongodb.com/manual/reference/operator/query MongoDB Docs}.
     */
    filter?: InputJsonValue
    /**
     * Additional options to pass to the `find` command ${@link https://docs.mongodb.com/manual/reference/command/find/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * UserSubClass aggregateRaw
   */
  export type UserSubClassAggregateRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * An array of aggregation stages to process and transform the document stream via the aggregation pipeline. ${@link https://docs.mongodb.com/manual/reference/operator/aggregation-pipeline MongoDB Docs}.
     */
    pipeline?: InputJsonValue[]
    /**
     * Additional options to pass to the `aggregate` command ${@link https://docs.mongodb.com/manual/reference/command/aggregate/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * UserSubClass without action
   */
  export type UserSubClassDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserSubClass
     */
    select?: UserSubClassSelect<ExtArgs> | null
    /**
     * Omit specific fields from the UserSubClass
     */
    omit?: UserSubClassOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserSubClassInclude<ExtArgs> | null
  }


  /**
   * Model PaidAmount
   */

  export type AggregatePaidAmount = {
    _count: PaidAmountCountAggregateOutputType | null
    _avg: PaidAmountAvgAggregateOutputType | null
    _sum: PaidAmountSumAggregateOutputType | null
    _min: PaidAmountMinAggregateOutputType | null
    _max: PaidAmountMaxAggregateOutputType | null
  }

  export type PaidAmountAvgAggregateOutputType = {
    price: number | null
  }

  export type PaidAmountSumAggregateOutputType = {
    price: number | null
  }

  export type PaidAmountMinAggregateOutputType = {
    id: string | null
    userId: string | null
    subClassId: string | null
    price: number | null
    status: $Enums.PayStatus | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PaidAmountMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    subClassId: string | null
    price: number | null
    status: $Enums.PayStatus | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PaidAmountCountAggregateOutputType = {
    id: number
    userId: number
    subClassId: number
    price: number
    status: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type PaidAmountAvgAggregateInputType = {
    price?: true
  }

  export type PaidAmountSumAggregateInputType = {
    price?: true
  }

  export type PaidAmountMinAggregateInputType = {
    id?: true
    userId?: true
    subClassId?: true
    price?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PaidAmountMaxAggregateInputType = {
    id?: true
    userId?: true
    subClassId?: true
    price?: true
    status?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PaidAmountCountAggregateInputType = {
    id?: true
    userId?: true
    subClassId?: true
    price?: true
    status?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type PaidAmountAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PaidAmount to aggregate.
     */
    where?: PaidAmountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaidAmounts to fetch.
     */
    orderBy?: PaidAmountOrderByWithRelationInput | PaidAmountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PaidAmountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaidAmounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaidAmounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PaidAmounts
    **/
    _count?: true | PaidAmountCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PaidAmountAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PaidAmountSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PaidAmountMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PaidAmountMaxAggregateInputType
  }

  export type GetPaidAmountAggregateType<T extends PaidAmountAggregateArgs> = {
        [P in keyof T & keyof AggregatePaidAmount]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePaidAmount[P]>
      : GetScalarType<T[P], AggregatePaidAmount[P]>
  }




  export type PaidAmountGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaidAmountWhereInput
    orderBy?: PaidAmountOrderByWithAggregationInput | PaidAmountOrderByWithAggregationInput[]
    by: PaidAmountScalarFieldEnum[] | PaidAmountScalarFieldEnum
    having?: PaidAmountScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PaidAmountCountAggregateInputType | true
    _avg?: PaidAmountAvgAggregateInputType
    _sum?: PaidAmountSumAggregateInputType
    _min?: PaidAmountMinAggregateInputType
    _max?: PaidAmountMaxAggregateInputType
  }

  export type PaidAmountGroupByOutputType = {
    id: string
    userId: string
    subClassId: string
    price: number
    status: $Enums.PayStatus | null
    createdAt: Date
    updatedAt: Date
    _count: PaidAmountCountAggregateOutputType | null
    _avg: PaidAmountAvgAggregateOutputType | null
    _sum: PaidAmountSumAggregateOutputType | null
    _min: PaidAmountMinAggregateOutputType | null
    _max: PaidAmountMaxAggregateOutputType | null
  }

  type GetPaidAmountGroupByPayload<T extends PaidAmountGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PaidAmountGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PaidAmountGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PaidAmountGroupByOutputType[P]>
            : GetScalarType<T[P], PaidAmountGroupByOutputType[P]>
        }
      >
    >


  export type PaidAmountSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    subClassId?: boolean
    price?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    subClass?: boolean | SubClassDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["paidAmount"]>



  export type PaidAmountSelectScalar = {
    id?: boolean
    userId?: boolean
    subClassId?: boolean
    price?: boolean
    status?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type PaidAmountOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "subClassId" | "price" | "status" | "createdAt" | "updatedAt", ExtArgs["result"]["paidAmount"]>
  export type PaidAmountInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    subClass?: boolean | SubClassDefaultArgs<ExtArgs>
  }

  export type $PaidAmountPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PaidAmount"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      subClass: Prisma.$SubClassPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      subClassId: string
      price: number
      status: $Enums.PayStatus | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["paidAmount"]>
    composites: {}
  }

  type PaidAmountGetPayload<S extends boolean | null | undefined | PaidAmountDefaultArgs> = $Result.GetResult<Prisma.$PaidAmountPayload, S>

  type PaidAmountCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PaidAmountFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PaidAmountCountAggregateInputType | true
    }

  export interface PaidAmountDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PaidAmount'], meta: { name: 'PaidAmount' } }
    /**
     * Find zero or one PaidAmount that matches the filter.
     * @param {PaidAmountFindUniqueArgs} args - Arguments to find a PaidAmount
     * @example
     * // Get one PaidAmount
     * const paidAmount = await prisma.paidAmount.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PaidAmountFindUniqueArgs>(args: SelectSubset<T, PaidAmountFindUniqueArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PaidAmount that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PaidAmountFindUniqueOrThrowArgs} args - Arguments to find a PaidAmount
     * @example
     * // Get one PaidAmount
     * const paidAmount = await prisma.paidAmount.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PaidAmountFindUniqueOrThrowArgs>(args: SelectSubset<T, PaidAmountFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PaidAmount that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountFindFirstArgs} args - Arguments to find a PaidAmount
     * @example
     * // Get one PaidAmount
     * const paidAmount = await prisma.paidAmount.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PaidAmountFindFirstArgs>(args?: SelectSubset<T, PaidAmountFindFirstArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PaidAmount that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountFindFirstOrThrowArgs} args - Arguments to find a PaidAmount
     * @example
     * // Get one PaidAmount
     * const paidAmount = await prisma.paidAmount.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PaidAmountFindFirstOrThrowArgs>(args?: SelectSubset<T, PaidAmountFindFirstOrThrowArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PaidAmounts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PaidAmounts
     * const paidAmounts = await prisma.paidAmount.findMany()
     * 
     * // Get first 10 PaidAmounts
     * const paidAmounts = await prisma.paidAmount.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const paidAmountWithIdOnly = await prisma.paidAmount.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PaidAmountFindManyArgs>(args?: SelectSubset<T, PaidAmountFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PaidAmount.
     * @param {PaidAmountCreateArgs} args - Arguments to create a PaidAmount.
     * @example
     * // Create one PaidAmount
     * const PaidAmount = await prisma.paidAmount.create({
     *   data: {
     *     // ... data to create a PaidAmount
     *   }
     * })
     * 
     */
    create<T extends PaidAmountCreateArgs>(args: SelectSubset<T, PaidAmountCreateArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PaidAmounts.
     * @param {PaidAmountCreateManyArgs} args - Arguments to create many PaidAmounts.
     * @example
     * // Create many PaidAmounts
     * const paidAmount = await prisma.paidAmount.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PaidAmountCreateManyArgs>(args?: SelectSubset<T, PaidAmountCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a PaidAmount.
     * @param {PaidAmountDeleteArgs} args - Arguments to delete one PaidAmount.
     * @example
     * // Delete one PaidAmount
     * const PaidAmount = await prisma.paidAmount.delete({
     *   where: {
     *     // ... filter to delete one PaidAmount
     *   }
     * })
     * 
     */
    delete<T extends PaidAmountDeleteArgs>(args: SelectSubset<T, PaidAmountDeleteArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PaidAmount.
     * @param {PaidAmountUpdateArgs} args - Arguments to update one PaidAmount.
     * @example
     * // Update one PaidAmount
     * const paidAmount = await prisma.paidAmount.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PaidAmountUpdateArgs>(args: SelectSubset<T, PaidAmountUpdateArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PaidAmounts.
     * @param {PaidAmountDeleteManyArgs} args - Arguments to filter PaidAmounts to delete.
     * @example
     * // Delete a few PaidAmounts
     * const { count } = await prisma.paidAmount.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PaidAmountDeleteManyArgs>(args?: SelectSubset<T, PaidAmountDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PaidAmounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PaidAmounts
     * const paidAmount = await prisma.paidAmount.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PaidAmountUpdateManyArgs>(args: SelectSubset<T, PaidAmountUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one PaidAmount.
     * @param {PaidAmountUpsertArgs} args - Arguments to update or create a PaidAmount.
     * @example
     * // Update or create a PaidAmount
     * const paidAmount = await prisma.paidAmount.upsert({
     *   create: {
     *     // ... data to create a PaidAmount
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PaidAmount we want to update
     *   }
     * })
     */
    upsert<T extends PaidAmountUpsertArgs>(args: SelectSubset<T, PaidAmountUpsertArgs<ExtArgs>>): Prisma__PaidAmountClient<$Result.GetResult<Prisma.$PaidAmountPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PaidAmounts that matches the filter.
     * @param {PaidAmountFindRawArgs} args - Select which filters you would like to apply.
     * @example
     * const paidAmount = await prisma.paidAmount.findRaw({
     *   filter: { age: { $gt: 25 } }
     * })
     */
    findRaw(args?: PaidAmountFindRawArgs): Prisma.PrismaPromise<JsonObject>

    /**
     * Perform aggregation operations on a PaidAmount.
     * @param {PaidAmountAggregateRawArgs} args - Select which aggregations you would like to apply.
     * @example
     * const paidAmount = await prisma.paidAmount.aggregateRaw({
     *   pipeline: [
     *     { $match: { status: "registered" } },
     *     { $group: { _id: "$country", total: { $sum: 1 } } }
     *   ]
     * })
     */
    aggregateRaw(args?: PaidAmountAggregateRawArgs): Prisma.PrismaPromise<JsonObject>


    /**
     * Count the number of PaidAmounts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountCountArgs} args - Arguments to filter PaidAmounts to count.
     * @example
     * // Count the number of PaidAmounts
     * const count = await prisma.paidAmount.count({
     *   where: {
     *     // ... the filter for the PaidAmounts we want to count
     *   }
     * })
    **/
    count<T extends PaidAmountCountArgs>(
      args?: Subset<T, PaidAmountCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PaidAmountCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PaidAmount.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaidAmountAggregateArgs>(args: Subset<T, PaidAmountAggregateArgs>): Prisma.PrismaPromise<GetPaidAmountAggregateType<T>>

    /**
     * Group by PaidAmount.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaidAmountGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PaidAmountGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PaidAmountGroupByArgs['orderBy'] }
        : { orderBy?: PaidAmountGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PaidAmountGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaidAmountGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PaidAmount model
   */
  readonly fields: PaidAmountFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PaidAmount.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PaidAmountClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    subClass<T extends SubClassDefaultArgs<ExtArgs> = {}>(args?: Subset<T, SubClassDefaultArgs<ExtArgs>>): Prisma__SubClassClient<$Result.GetResult<Prisma.$SubClassPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PaidAmount model
   */
  interface PaidAmountFieldRefs {
    readonly id: FieldRef<"PaidAmount", 'String'>
    readonly userId: FieldRef<"PaidAmount", 'String'>
    readonly subClassId: FieldRef<"PaidAmount", 'String'>
    readonly price: FieldRef<"PaidAmount", 'Int'>
    readonly status: FieldRef<"PaidAmount", 'PayStatus'>
    readonly createdAt: FieldRef<"PaidAmount", 'DateTime'>
    readonly updatedAt: FieldRef<"PaidAmount", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PaidAmount findUnique
   */
  export type PaidAmountFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * Filter, which PaidAmount to fetch.
     */
    where: PaidAmountWhereUniqueInput
  }

  /**
   * PaidAmount findUniqueOrThrow
   */
  export type PaidAmountFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * Filter, which PaidAmount to fetch.
     */
    where: PaidAmountWhereUniqueInput
  }

  /**
   * PaidAmount findFirst
   */
  export type PaidAmountFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * Filter, which PaidAmount to fetch.
     */
    where?: PaidAmountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaidAmounts to fetch.
     */
    orderBy?: PaidAmountOrderByWithRelationInput | PaidAmountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PaidAmounts.
     */
    cursor?: PaidAmountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaidAmounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaidAmounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PaidAmounts.
     */
    distinct?: PaidAmountScalarFieldEnum | PaidAmountScalarFieldEnum[]
  }

  /**
   * PaidAmount findFirstOrThrow
   */
  export type PaidAmountFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * Filter, which PaidAmount to fetch.
     */
    where?: PaidAmountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaidAmounts to fetch.
     */
    orderBy?: PaidAmountOrderByWithRelationInput | PaidAmountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PaidAmounts.
     */
    cursor?: PaidAmountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaidAmounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaidAmounts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PaidAmounts.
     */
    distinct?: PaidAmountScalarFieldEnum | PaidAmountScalarFieldEnum[]
  }

  /**
   * PaidAmount findMany
   */
  export type PaidAmountFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * Filter, which PaidAmounts to fetch.
     */
    where?: PaidAmountWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PaidAmounts to fetch.
     */
    orderBy?: PaidAmountOrderByWithRelationInput | PaidAmountOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PaidAmounts.
     */
    cursor?: PaidAmountWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PaidAmounts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PaidAmounts.
     */
    skip?: number
    distinct?: PaidAmountScalarFieldEnum | PaidAmountScalarFieldEnum[]
  }

  /**
   * PaidAmount create
   */
  export type PaidAmountCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * The data needed to create a PaidAmount.
     */
    data: XOR<PaidAmountCreateInput, PaidAmountUncheckedCreateInput>
  }

  /**
   * PaidAmount createMany
   */
  export type PaidAmountCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PaidAmounts.
     */
    data: PaidAmountCreateManyInput | PaidAmountCreateManyInput[]
  }

  /**
   * PaidAmount update
   */
  export type PaidAmountUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * The data needed to update a PaidAmount.
     */
    data: XOR<PaidAmountUpdateInput, PaidAmountUncheckedUpdateInput>
    /**
     * Choose, which PaidAmount to update.
     */
    where: PaidAmountWhereUniqueInput
  }

  /**
   * PaidAmount updateMany
   */
  export type PaidAmountUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PaidAmounts.
     */
    data: XOR<PaidAmountUpdateManyMutationInput, PaidAmountUncheckedUpdateManyInput>
    /**
     * Filter which PaidAmounts to update
     */
    where?: PaidAmountWhereInput
    /**
     * Limit how many PaidAmounts to update.
     */
    limit?: number
  }

  /**
   * PaidAmount upsert
   */
  export type PaidAmountUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * The filter to search for the PaidAmount to update in case it exists.
     */
    where: PaidAmountWhereUniqueInput
    /**
     * In case the PaidAmount found by the `where` argument doesn't exist, create a new PaidAmount with this data.
     */
    create: XOR<PaidAmountCreateInput, PaidAmountUncheckedCreateInput>
    /**
     * In case the PaidAmount was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PaidAmountUpdateInput, PaidAmountUncheckedUpdateInput>
  }

  /**
   * PaidAmount delete
   */
  export type PaidAmountDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
    /**
     * Filter which PaidAmount to delete.
     */
    where: PaidAmountWhereUniqueInput
  }

  /**
   * PaidAmount deleteMany
   */
  export type PaidAmountDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PaidAmounts to delete
     */
    where?: PaidAmountWhereInput
    /**
     * Limit how many PaidAmounts to delete.
     */
    limit?: number
  }

  /**
   * PaidAmount findRaw
   */
  export type PaidAmountFindRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The query predicate filter. If unspecified, then all documents in the collection will match the predicate. ${@link https://docs.mongodb.com/manual/reference/operator/query MongoDB Docs}.
     */
    filter?: InputJsonValue
    /**
     * Additional options to pass to the `find` command ${@link https://docs.mongodb.com/manual/reference/command/find/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * PaidAmount aggregateRaw
   */
  export type PaidAmountAggregateRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * An array of aggregation stages to process and transform the document stream via the aggregation pipeline. ${@link https://docs.mongodb.com/manual/reference/operator/aggregation-pipeline MongoDB Docs}.
     */
    pipeline?: InputJsonValue[]
    /**
     * Additional options to pass to the `aggregate` command ${@link https://docs.mongodb.com/manual/reference/command/aggregate/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * PaidAmount without action
   */
  export type PaidAmountDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaidAmount
     */
    select?: PaidAmountSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PaidAmount
     */
    omit?: PaidAmountOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaidAmountInclude<ExtArgs> | null
  }


  /**
   * Model Admin
   */

  export type AggregateAdmin = {
    _count: AdminCountAggregateOutputType | null
    _min: AdminMinAggregateOutputType | null
    _max: AdminMaxAggregateOutputType | null
  }

  export type AdminMinAggregateOutputType = {
    id: string | null
    name: string | null
    phone: string | null
    email: string | null
    role: $Enums.Role | null
    password: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AdminMaxAggregateOutputType = {
    id: string | null
    name: string | null
    phone: string | null
    email: string | null
    role: $Enums.Role | null
    password: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type AdminCountAggregateOutputType = {
    id: number
    name: number
    phone: number
    email: number
    role: number
    password: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type AdminMinAggregateInputType = {
    id?: true
    name?: true
    phone?: true
    email?: true
    role?: true
    password?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AdminMaxAggregateInputType = {
    id?: true
    name?: true
    phone?: true
    email?: true
    role?: true
    password?: true
    createdAt?: true
    updatedAt?: true
  }

  export type AdminCountAggregateInputType = {
    id?: true
    name?: true
    phone?: true
    email?: true
    role?: true
    password?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type AdminAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Admin to aggregate.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Admins
    **/
    _count?: true | AdminCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AdminMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AdminMaxAggregateInputType
  }

  export type GetAdminAggregateType<T extends AdminAggregateArgs> = {
        [P in keyof T & keyof AggregateAdmin]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAdmin[P]>
      : GetScalarType<T[P], AggregateAdmin[P]>
  }




  export type AdminGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AdminWhereInput
    orderBy?: AdminOrderByWithAggregationInput | AdminOrderByWithAggregationInput[]
    by: AdminScalarFieldEnum[] | AdminScalarFieldEnum
    having?: AdminScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AdminCountAggregateInputType | true
    _min?: AdminMinAggregateInputType
    _max?: AdminMaxAggregateInputType
  }

  export type AdminGroupByOutputType = {
    id: string
    name: string
    phone: string
    email: string
    role: $Enums.Role
    password: string
    createdAt: Date
    updatedAt: Date
    _count: AdminCountAggregateOutputType | null
    _min: AdminMinAggregateOutputType | null
    _max: AdminMaxAggregateOutputType | null
  }

  type GetAdminGroupByPayload<T extends AdminGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AdminGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AdminGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AdminGroupByOutputType[P]>
            : GetScalarType<T[P], AdminGroupByOutputType[P]>
        }
      >
    >


  export type AdminSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    phone?: boolean
    email?: boolean
    role?: boolean
    password?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["admin"]>



  export type AdminSelectScalar = {
    id?: boolean
    name?: boolean
    phone?: boolean
    email?: boolean
    role?: boolean
    password?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type AdminOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "phone" | "email" | "role" | "password" | "createdAt" | "updatedAt", ExtArgs["result"]["admin"]>

  export type $AdminPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Admin"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      phone: string
      email: string
      role: $Enums.Role
      password: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["admin"]>
    composites: {}
  }

  type AdminGetPayload<S extends boolean | null | undefined | AdminDefaultArgs> = $Result.GetResult<Prisma.$AdminPayload, S>

  type AdminCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AdminFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AdminCountAggregateInputType | true
    }

  export interface AdminDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Admin'], meta: { name: 'Admin' } }
    /**
     * Find zero or one Admin that matches the filter.
     * @param {AdminFindUniqueArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AdminFindUniqueArgs>(args: SelectSubset<T, AdminFindUniqueArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Admin that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AdminFindUniqueOrThrowArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AdminFindUniqueOrThrowArgs>(args: SelectSubset<T, AdminFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Admin that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminFindFirstArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AdminFindFirstArgs>(args?: SelectSubset<T, AdminFindFirstArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Admin that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminFindFirstOrThrowArgs} args - Arguments to find a Admin
     * @example
     * // Get one Admin
     * const admin = await prisma.admin.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AdminFindFirstOrThrowArgs>(args?: SelectSubset<T, AdminFindFirstOrThrowArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Admins that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Admins
     * const admins = await prisma.admin.findMany()
     * 
     * // Get first 10 Admins
     * const admins = await prisma.admin.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const adminWithIdOnly = await prisma.admin.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AdminFindManyArgs>(args?: SelectSubset<T, AdminFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Admin.
     * @param {AdminCreateArgs} args - Arguments to create a Admin.
     * @example
     * // Create one Admin
     * const Admin = await prisma.admin.create({
     *   data: {
     *     // ... data to create a Admin
     *   }
     * })
     * 
     */
    create<T extends AdminCreateArgs>(args: SelectSubset<T, AdminCreateArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Admins.
     * @param {AdminCreateManyArgs} args - Arguments to create many Admins.
     * @example
     * // Create many Admins
     * const admin = await prisma.admin.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AdminCreateManyArgs>(args?: SelectSubset<T, AdminCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Admin.
     * @param {AdminDeleteArgs} args - Arguments to delete one Admin.
     * @example
     * // Delete one Admin
     * const Admin = await prisma.admin.delete({
     *   where: {
     *     // ... filter to delete one Admin
     *   }
     * })
     * 
     */
    delete<T extends AdminDeleteArgs>(args: SelectSubset<T, AdminDeleteArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Admin.
     * @param {AdminUpdateArgs} args - Arguments to update one Admin.
     * @example
     * // Update one Admin
     * const admin = await prisma.admin.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AdminUpdateArgs>(args: SelectSubset<T, AdminUpdateArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Admins.
     * @param {AdminDeleteManyArgs} args - Arguments to filter Admins to delete.
     * @example
     * // Delete a few Admins
     * const { count } = await prisma.admin.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AdminDeleteManyArgs>(args?: SelectSubset<T, AdminDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Admins.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Admins
     * const admin = await prisma.admin.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AdminUpdateManyArgs>(args: SelectSubset<T, AdminUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Admin.
     * @param {AdminUpsertArgs} args - Arguments to update or create a Admin.
     * @example
     * // Update or create a Admin
     * const admin = await prisma.admin.upsert({
     *   create: {
     *     // ... data to create a Admin
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Admin we want to update
     *   }
     * })
     */
    upsert<T extends AdminUpsertArgs>(args: SelectSubset<T, AdminUpsertArgs<ExtArgs>>): Prisma__AdminClient<$Result.GetResult<Prisma.$AdminPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Admins that matches the filter.
     * @param {AdminFindRawArgs} args - Select which filters you would like to apply.
     * @example
     * const admin = await prisma.admin.findRaw({
     *   filter: { age: { $gt: 25 } }
     * })
     */
    findRaw(args?: AdminFindRawArgs): Prisma.PrismaPromise<JsonObject>

    /**
     * Perform aggregation operations on a Admin.
     * @param {AdminAggregateRawArgs} args - Select which aggregations you would like to apply.
     * @example
     * const admin = await prisma.admin.aggregateRaw({
     *   pipeline: [
     *     { $match: { status: "registered" } },
     *     { $group: { _id: "$country", total: { $sum: 1 } } }
     *   ]
     * })
     */
    aggregateRaw(args?: AdminAggregateRawArgs): Prisma.PrismaPromise<JsonObject>


    /**
     * Count the number of Admins.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminCountArgs} args - Arguments to filter Admins to count.
     * @example
     * // Count the number of Admins
     * const count = await prisma.admin.count({
     *   where: {
     *     // ... the filter for the Admins we want to count
     *   }
     * })
    **/
    count<T extends AdminCountArgs>(
      args?: Subset<T, AdminCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AdminCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Admin.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AdminAggregateArgs>(args: Subset<T, AdminAggregateArgs>): Prisma.PrismaPromise<GetAdminAggregateType<T>>

    /**
     * Group by Admin.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AdminGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AdminGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AdminGroupByArgs['orderBy'] }
        : { orderBy?: AdminGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AdminGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAdminGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Admin model
   */
  readonly fields: AdminFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Admin.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AdminClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Admin model
   */
  interface AdminFieldRefs {
    readonly id: FieldRef<"Admin", 'String'>
    readonly name: FieldRef<"Admin", 'String'>
    readonly phone: FieldRef<"Admin", 'String'>
    readonly email: FieldRef<"Admin", 'String'>
    readonly role: FieldRef<"Admin", 'Role'>
    readonly password: FieldRef<"Admin", 'String'>
    readonly createdAt: FieldRef<"Admin", 'DateTime'>
    readonly updatedAt: FieldRef<"Admin", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Admin findUnique
   */
  export type AdminFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin findUniqueOrThrow
   */
  export type AdminFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin findFirst
   */
  export type AdminFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Admins.
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Admins.
     */
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * Admin findFirstOrThrow
   */
  export type AdminFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Filter, which Admin to fetch.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Admins.
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Admins.
     */
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * Admin findMany
   */
  export type AdminFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Filter, which Admins to fetch.
     */
    where?: AdminWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Admins to fetch.
     */
    orderBy?: AdminOrderByWithRelationInput | AdminOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Admins.
     */
    cursor?: AdminWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Admins from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Admins.
     */
    skip?: number
    distinct?: AdminScalarFieldEnum | AdminScalarFieldEnum[]
  }

  /**
   * Admin create
   */
  export type AdminCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * The data needed to create a Admin.
     */
    data: XOR<AdminCreateInput, AdminUncheckedCreateInput>
  }

  /**
   * Admin createMany
   */
  export type AdminCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Admins.
     */
    data: AdminCreateManyInput | AdminCreateManyInput[]
  }

  /**
   * Admin update
   */
  export type AdminUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * The data needed to update a Admin.
     */
    data: XOR<AdminUpdateInput, AdminUncheckedUpdateInput>
    /**
     * Choose, which Admin to update.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin updateMany
   */
  export type AdminUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Admins.
     */
    data: XOR<AdminUpdateManyMutationInput, AdminUncheckedUpdateManyInput>
    /**
     * Filter which Admins to update
     */
    where?: AdminWhereInput
    /**
     * Limit how many Admins to update.
     */
    limit?: number
  }

  /**
   * Admin upsert
   */
  export type AdminUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * The filter to search for the Admin to update in case it exists.
     */
    where: AdminWhereUniqueInput
    /**
     * In case the Admin found by the `where` argument doesn't exist, create a new Admin with this data.
     */
    create: XOR<AdminCreateInput, AdminUncheckedCreateInput>
    /**
     * In case the Admin was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AdminUpdateInput, AdminUncheckedUpdateInput>
  }

  /**
   * Admin delete
   */
  export type AdminDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
    /**
     * Filter which Admin to delete.
     */
    where: AdminWhereUniqueInput
  }

  /**
   * Admin deleteMany
   */
  export type AdminDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Admins to delete
     */
    where?: AdminWhereInput
    /**
     * Limit how many Admins to delete.
     */
    limit?: number
  }

  /**
   * Admin findRaw
   */
  export type AdminFindRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The query predicate filter. If unspecified, then all documents in the collection will match the predicate. ${@link https://docs.mongodb.com/manual/reference/operator/query MongoDB Docs}.
     */
    filter?: InputJsonValue
    /**
     * Additional options to pass to the `find` command ${@link https://docs.mongodb.com/manual/reference/command/find/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * Admin aggregateRaw
   */
  export type AdminAggregateRawArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * An array of aggregation stages to process and transform the document stream via the aggregation pipeline. ${@link https://docs.mongodb.com/manual/reference/operator/aggregation-pipeline MongoDB Docs}.
     */
    pipeline?: InputJsonValue[]
    /**
     * Additional options to pass to the `aggregate` command ${@link https://docs.mongodb.com/manual/reference/command/aggregate/#command-fields MongoDB Docs}.
     */
    options?: InputJsonValue
  }

  /**
   * Admin without action
   */
  export type AdminDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Admin
     */
    select?: AdminSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Admin
     */
    omit?: AdminOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const UserScalarFieldEnum: {
    id: 'id',
    nationalCode: 'nationalCode',
    name: 'name',
    phone: 'phone',
    motherName: 'motherName',
    fatherName: 'fatherName',
    birthDate: 'birthDate',
    gender: 'gender',
    address: 'address',
    city: 'city',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const ClassScalarFieldEnum: {
    id: 'id',
    name: 'name',
    subClassCount: 'subClassCount',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type ClassScalarFieldEnum = (typeof ClassScalarFieldEnum)[keyof typeof ClassScalarFieldEnum]


  export const SubClassScalarFieldEnum: {
    id: 'id',
    classId: 'classId',
    name: 'name',
    totalAmount: 'totalAmount',
    teacher: 'teacher',
    day: 'day',
    startTime: 'startTime',
    endTime: 'endTime',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SubClassScalarFieldEnum = (typeof SubClassScalarFieldEnum)[keyof typeof SubClassScalarFieldEnum]


  export const UserSubClassScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    subClassId: 'subClassId',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserSubClassScalarFieldEnum = (typeof UserSubClassScalarFieldEnum)[keyof typeof UserSubClassScalarFieldEnum]


  export const PaidAmountScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    subClassId: 'subClassId',
    price: 'price',
    status: 'status',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type PaidAmountScalarFieldEnum = (typeof PaidAmountScalarFieldEnum)[keyof typeof PaidAmountScalarFieldEnum]


  export const AdminScalarFieldEnum: {
    id: 'id',
    name: 'name',
    phone: 'phone',
    email: 'email',
    role: 'role',
    password: 'password',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type AdminScalarFieldEnum = (typeof AdminScalarFieldEnum)[keyof typeof AdminScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Day'
   */
  export type EnumDayFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Day'>
    


  /**
   * Reference to a field of type 'Day[]'
   */
  export type ListEnumDayFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Day[]'>
    


  /**
   * Reference to a field of type 'PayStatus'
   */
  export type EnumPayStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PayStatus'>
    


  /**
   * Reference to a field of type 'PayStatus[]'
   */
  export type ListEnumPayStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PayStatus[]'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'Role[]'
   */
  export type ListEnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    nationalCode?: StringFilter<"User"> | string
    name?: StringFilter<"User"> | string
    phone?: StringFilter<"User"> | string
    motherName?: StringFilter<"User"> | string
    fatherName?: StringFilter<"User"> | string
    birthDate?: DateTimeFilter<"User"> | Date | string
    gender?: StringFilter<"User"> | string
    address?: StringFilter<"User"> | string
    city?: StringFilter<"User"> | string
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    paidAmounts?: PaidAmountListRelationFilter
    userSubClasses?: UserSubClassListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    nationalCode?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    motherName?: SortOrder
    fatherName?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    address?: SortOrder
    city?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    paidAmounts?: PaidAmountOrderByRelationAggregateInput
    userSubClasses?: UserSubClassOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    nationalCode?: string
    name?: string
    phone?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    motherName?: StringFilter<"User"> | string
    fatherName?: StringFilter<"User"> | string
    birthDate?: DateTimeFilter<"User"> | Date | string
    gender?: StringFilter<"User"> | string
    address?: StringFilter<"User"> | string
    city?: StringFilter<"User"> | string
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    paidAmounts?: PaidAmountListRelationFilter
    userSubClasses?: UserSubClassListRelationFilter
  }, "id" | "nationalCode" | "name" | "phone">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    nationalCode?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    motherName?: SortOrder
    fatherName?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    address?: SortOrder
    city?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    nationalCode?: StringWithAggregatesFilter<"User"> | string
    name?: StringWithAggregatesFilter<"User"> | string
    phone?: StringWithAggregatesFilter<"User"> | string
    motherName?: StringWithAggregatesFilter<"User"> | string
    fatherName?: StringWithAggregatesFilter<"User"> | string
    birthDate?: DateTimeWithAggregatesFilter<"User"> | Date | string
    gender?: StringWithAggregatesFilter<"User"> | string
    address?: StringWithAggregatesFilter<"User"> | string
    city?: StringWithAggregatesFilter<"User"> | string
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type ClassWhereInput = {
    AND?: ClassWhereInput | ClassWhereInput[]
    OR?: ClassWhereInput[]
    NOT?: ClassWhereInput | ClassWhereInput[]
    id?: StringFilter<"Class"> | string
    name?: StringFilter<"Class"> | string
    subClassCount?: IntFilter<"Class"> | number
    createdAt?: DateTimeFilter<"Class"> | Date | string
    updatedAt?: DateTimeFilter<"Class"> | Date | string
    subClass?: SubClassListRelationFilter
  }

  export type ClassOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    subClassCount?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    subClass?: SubClassOrderByRelationAggregateInput
  }

  export type ClassWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    name?: string
    AND?: ClassWhereInput | ClassWhereInput[]
    OR?: ClassWhereInput[]
    NOT?: ClassWhereInput | ClassWhereInput[]
    subClassCount?: IntFilter<"Class"> | number
    createdAt?: DateTimeFilter<"Class"> | Date | string
    updatedAt?: DateTimeFilter<"Class"> | Date | string
    subClass?: SubClassListRelationFilter
  }, "id" | "name">

  export type ClassOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    subClassCount?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: ClassCountOrderByAggregateInput
    _avg?: ClassAvgOrderByAggregateInput
    _max?: ClassMaxOrderByAggregateInput
    _min?: ClassMinOrderByAggregateInput
    _sum?: ClassSumOrderByAggregateInput
  }

  export type ClassScalarWhereWithAggregatesInput = {
    AND?: ClassScalarWhereWithAggregatesInput | ClassScalarWhereWithAggregatesInput[]
    OR?: ClassScalarWhereWithAggregatesInput[]
    NOT?: ClassScalarWhereWithAggregatesInput | ClassScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Class"> | string
    name?: StringWithAggregatesFilter<"Class"> | string
    subClassCount?: IntWithAggregatesFilter<"Class"> | number
    createdAt?: DateTimeWithAggregatesFilter<"Class"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Class"> | Date | string
  }

  export type SubClassWhereInput = {
    AND?: SubClassWhereInput | SubClassWhereInput[]
    OR?: SubClassWhereInput[]
    NOT?: SubClassWhereInput | SubClassWhereInput[]
    id?: StringFilter<"SubClass"> | string
    classId?: StringFilter<"SubClass"> | string
    name?: StringFilter<"SubClass"> | string
    totalAmount?: IntFilter<"SubClass"> | number
    teacher?: StringFilter<"SubClass"> | string
    day?: EnumDayFilter<"SubClass"> | $Enums.Day
    startTime?: StringFilter<"SubClass"> | string
    endTime?: StringFilter<"SubClass"> | string
    createdAt?: DateTimeFilter<"SubClass"> | Date | string
    updatedAt?: DateTimeFilter<"SubClass"> | Date | string
    class?: XOR<ClassScalarRelationFilter, ClassWhereInput>
    userSubClasses?: UserSubClassListRelationFilter
    paidAmounts?: PaidAmountListRelationFilter
  }

  export type SubClassOrderByWithRelationInput = {
    id?: SortOrder
    classId?: SortOrder
    name?: SortOrder
    totalAmount?: SortOrder
    teacher?: SortOrder
    day?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    class?: ClassOrderByWithRelationInput
    userSubClasses?: UserSubClassOrderByRelationAggregateInput
    paidAmounts?: PaidAmountOrderByRelationAggregateInput
  }

  export type SubClassWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: SubClassWhereInput | SubClassWhereInput[]
    OR?: SubClassWhereInput[]
    NOT?: SubClassWhereInput | SubClassWhereInput[]
    classId?: StringFilter<"SubClass"> | string
    name?: StringFilter<"SubClass"> | string
    totalAmount?: IntFilter<"SubClass"> | number
    teacher?: StringFilter<"SubClass"> | string
    day?: EnumDayFilter<"SubClass"> | $Enums.Day
    startTime?: StringFilter<"SubClass"> | string
    endTime?: StringFilter<"SubClass"> | string
    createdAt?: DateTimeFilter<"SubClass"> | Date | string
    updatedAt?: DateTimeFilter<"SubClass"> | Date | string
    class?: XOR<ClassScalarRelationFilter, ClassWhereInput>
    userSubClasses?: UserSubClassListRelationFilter
    paidAmounts?: PaidAmountListRelationFilter
  }, "id">

  export type SubClassOrderByWithAggregationInput = {
    id?: SortOrder
    classId?: SortOrder
    name?: SortOrder
    totalAmount?: SortOrder
    teacher?: SortOrder
    day?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SubClassCountOrderByAggregateInput
    _avg?: SubClassAvgOrderByAggregateInput
    _max?: SubClassMaxOrderByAggregateInput
    _min?: SubClassMinOrderByAggregateInput
    _sum?: SubClassSumOrderByAggregateInput
  }

  export type SubClassScalarWhereWithAggregatesInput = {
    AND?: SubClassScalarWhereWithAggregatesInput | SubClassScalarWhereWithAggregatesInput[]
    OR?: SubClassScalarWhereWithAggregatesInput[]
    NOT?: SubClassScalarWhereWithAggregatesInput | SubClassScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"SubClass"> | string
    classId?: StringWithAggregatesFilter<"SubClass"> | string
    name?: StringWithAggregatesFilter<"SubClass"> | string
    totalAmount?: IntWithAggregatesFilter<"SubClass"> | number
    teacher?: StringWithAggregatesFilter<"SubClass"> | string
    day?: EnumDayWithAggregatesFilter<"SubClass"> | $Enums.Day
    startTime?: StringWithAggregatesFilter<"SubClass"> | string
    endTime?: StringWithAggregatesFilter<"SubClass"> | string
    createdAt?: DateTimeWithAggregatesFilter<"SubClass"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"SubClass"> | Date | string
  }

  export type UserSubClassWhereInput = {
    AND?: UserSubClassWhereInput | UserSubClassWhereInput[]
    OR?: UserSubClassWhereInput[]
    NOT?: UserSubClassWhereInput | UserSubClassWhereInput[]
    id?: StringFilter<"UserSubClass"> | string
    userId?: StringFilter<"UserSubClass"> | string
    subClassId?: StringFilter<"UserSubClass"> | string
    createdAt?: DateTimeFilter<"UserSubClass"> | Date | string
    updatedAt?: DateTimeFilter<"UserSubClass"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    subClass?: XOR<SubClassScalarRelationFilter, SubClassWhereInput>
  }

  export type UserSubClassOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    subClass?: SubClassOrderByWithRelationInput
  }

  export type UserSubClassWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: UserSubClassWhereInput | UserSubClassWhereInput[]
    OR?: UserSubClassWhereInput[]
    NOT?: UserSubClassWhereInput | UserSubClassWhereInput[]
    userId?: StringFilter<"UserSubClass"> | string
    subClassId?: StringFilter<"UserSubClass"> | string
    createdAt?: DateTimeFilter<"UserSubClass"> | Date | string
    updatedAt?: DateTimeFilter<"UserSubClass"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    subClass?: XOR<SubClassScalarRelationFilter, SubClassWhereInput>
  }, "id">

  export type UserSubClassOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserSubClassCountOrderByAggregateInput
    _max?: UserSubClassMaxOrderByAggregateInput
    _min?: UserSubClassMinOrderByAggregateInput
  }

  export type UserSubClassScalarWhereWithAggregatesInput = {
    AND?: UserSubClassScalarWhereWithAggregatesInput | UserSubClassScalarWhereWithAggregatesInput[]
    OR?: UserSubClassScalarWhereWithAggregatesInput[]
    NOT?: UserSubClassScalarWhereWithAggregatesInput | UserSubClassScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"UserSubClass"> | string
    userId?: StringWithAggregatesFilter<"UserSubClass"> | string
    subClassId?: StringWithAggregatesFilter<"UserSubClass"> | string
    createdAt?: DateTimeWithAggregatesFilter<"UserSubClass"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"UserSubClass"> | Date | string
  }

  export type PaidAmountWhereInput = {
    AND?: PaidAmountWhereInput | PaidAmountWhereInput[]
    OR?: PaidAmountWhereInput[]
    NOT?: PaidAmountWhereInput | PaidAmountWhereInput[]
    id?: StringFilter<"PaidAmount"> | string
    userId?: StringFilter<"PaidAmount"> | string
    subClassId?: StringFilter<"PaidAmount"> | string
    price?: IntFilter<"PaidAmount"> | number
    status?: EnumPayStatusNullableFilter<"PaidAmount"> | $Enums.PayStatus | null
    createdAt?: DateTimeFilter<"PaidAmount"> | Date | string
    updatedAt?: DateTimeFilter<"PaidAmount"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    subClass?: XOR<SubClassScalarRelationFilter, SubClassWhereInput>
  }

  export type PaidAmountOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    price?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
    subClass?: SubClassOrderByWithRelationInput
  }

  export type PaidAmountWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: PaidAmountWhereInput | PaidAmountWhereInput[]
    OR?: PaidAmountWhereInput[]
    NOT?: PaidAmountWhereInput | PaidAmountWhereInput[]
    userId?: StringFilter<"PaidAmount"> | string
    subClassId?: StringFilter<"PaidAmount"> | string
    price?: IntFilter<"PaidAmount"> | number
    status?: EnumPayStatusNullableFilter<"PaidAmount"> | $Enums.PayStatus | null
    createdAt?: DateTimeFilter<"PaidAmount"> | Date | string
    updatedAt?: DateTimeFilter<"PaidAmount"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    subClass?: XOR<SubClassScalarRelationFilter, SubClassWhereInput>
  }, "id">

  export type PaidAmountOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    price?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: PaidAmountCountOrderByAggregateInput
    _avg?: PaidAmountAvgOrderByAggregateInput
    _max?: PaidAmountMaxOrderByAggregateInput
    _min?: PaidAmountMinOrderByAggregateInput
    _sum?: PaidAmountSumOrderByAggregateInput
  }

  export type PaidAmountScalarWhereWithAggregatesInput = {
    AND?: PaidAmountScalarWhereWithAggregatesInput | PaidAmountScalarWhereWithAggregatesInput[]
    OR?: PaidAmountScalarWhereWithAggregatesInput[]
    NOT?: PaidAmountScalarWhereWithAggregatesInput | PaidAmountScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PaidAmount"> | string
    userId?: StringWithAggregatesFilter<"PaidAmount"> | string
    subClassId?: StringWithAggregatesFilter<"PaidAmount"> | string
    price?: IntWithAggregatesFilter<"PaidAmount"> | number
    status?: EnumPayStatusNullableWithAggregatesFilter<"PaidAmount"> | $Enums.PayStatus | null
    createdAt?: DateTimeWithAggregatesFilter<"PaidAmount"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"PaidAmount"> | Date | string
  }

  export type AdminWhereInput = {
    AND?: AdminWhereInput | AdminWhereInput[]
    OR?: AdminWhereInput[]
    NOT?: AdminWhereInput | AdminWhereInput[]
    id?: StringFilter<"Admin"> | string
    name?: StringFilter<"Admin"> | string
    phone?: StringFilter<"Admin"> | string
    email?: StringFilter<"Admin"> | string
    role?: EnumRoleFilter<"Admin"> | $Enums.Role
    password?: StringFilter<"Admin"> | string
    createdAt?: DateTimeFilter<"Admin"> | Date | string
    updatedAt?: DateTimeFilter<"Admin"> | Date | string
  }

  export type AdminOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    role?: SortOrder
    password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AdminWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    phone?: string
    email?: string
    AND?: AdminWhereInput | AdminWhereInput[]
    OR?: AdminWhereInput[]
    NOT?: AdminWhereInput | AdminWhereInput[]
    name?: StringFilter<"Admin"> | string
    role?: EnumRoleFilter<"Admin"> | $Enums.Role
    password?: StringFilter<"Admin"> | string
    createdAt?: DateTimeFilter<"Admin"> | Date | string
    updatedAt?: DateTimeFilter<"Admin"> | Date | string
  }, "id" | "phone" | "email">

  export type AdminOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    role?: SortOrder
    password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: AdminCountOrderByAggregateInput
    _max?: AdminMaxOrderByAggregateInput
    _min?: AdminMinOrderByAggregateInput
  }

  export type AdminScalarWhereWithAggregatesInput = {
    AND?: AdminScalarWhereWithAggregatesInput | AdminScalarWhereWithAggregatesInput[]
    OR?: AdminScalarWhereWithAggregatesInput[]
    NOT?: AdminScalarWhereWithAggregatesInput | AdminScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Admin"> | string
    name?: StringWithAggregatesFilter<"Admin"> | string
    phone?: StringWithAggregatesFilter<"Admin"> | string
    email?: StringWithAggregatesFilter<"Admin"> | string
    role?: EnumRoleWithAggregatesFilter<"Admin"> | $Enums.Role
    password?: StringWithAggregatesFilter<"Admin"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Admin"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Admin"> | Date | string
  }

  export type UserCreateInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paidAmounts?: PaidAmountCreateNestedManyWithoutUserInput
    userSubClasses?: UserSubClassCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paidAmounts?: PaidAmountUncheckedCreateNestedManyWithoutUserInput
    userSubClasses?: UserSubClassUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paidAmounts?: PaidAmountUpdateManyWithoutUserNestedInput
    userSubClasses?: UserSubClassUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paidAmounts?: PaidAmountUncheckedUpdateManyWithoutUserNestedInput
    userSubClasses?: UserSubClassUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ClassCreateInput = {
    id?: string
    name: string
    subClassCount: number
    createdAt?: Date | string
    updatedAt?: Date | string
    subClass?: SubClassCreateNestedManyWithoutClassInput
  }

  export type ClassUncheckedCreateInput = {
    id?: string
    name: string
    subClassCount: number
    createdAt?: Date | string
    updatedAt?: Date | string
    subClass?: SubClassUncheckedCreateNestedManyWithoutClassInput
  }

  export type ClassUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    subClassCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    subClass?: SubClassUpdateManyWithoutClassNestedInput
  }

  export type ClassUncheckedUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    subClassCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    subClass?: SubClassUncheckedUpdateManyWithoutClassNestedInput
  }

  export type ClassCreateManyInput = {
    id?: string
    name: string
    subClassCount: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ClassUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    subClassCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ClassUncheckedUpdateManyInput = {
    name?: StringFieldUpdateOperationsInput | string
    subClassCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SubClassCreateInput = {
    id?: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    class: ClassCreateNestedOneWithoutSubClassInput
    userSubClasses?: UserSubClassCreateNestedManyWithoutSubClassInput
    paidAmounts?: PaidAmountCreateNestedManyWithoutSubClassInput
  }

  export type SubClassUncheckedCreateInput = {
    id?: string
    classId: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userSubClasses?: UserSubClassUncheckedCreateNestedManyWithoutSubClassInput
    paidAmounts?: PaidAmountUncheckedCreateNestedManyWithoutSubClassInput
  }

  export type SubClassUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    class?: ClassUpdateOneRequiredWithoutSubClassNestedInput
    userSubClasses?: UserSubClassUpdateManyWithoutSubClassNestedInput
    paidAmounts?: PaidAmountUpdateManyWithoutSubClassNestedInput
  }

  export type SubClassUncheckedUpdateInput = {
    classId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userSubClasses?: UserSubClassUncheckedUpdateManyWithoutSubClassNestedInput
    paidAmounts?: PaidAmountUncheckedUpdateManyWithoutSubClassNestedInput
  }

  export type SubClassCreateManyInput = {
    id?: string
    classId: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SubClassUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SubClassUncheckedUpdateManyInput = {
    classId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassCreateInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutUserSubClassesInput
    subClass: SubClassCreateNestedOneWithoutUserSubClassesInput
  }

  export type UserSubClassUncheckedCreateInput = {
    id?: string
    userId: string
    subClassId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserSubClassUpdateInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutUserSubClassesNestedInput
    subClass?: SubClassUpdateOneRequiredWithoutUserSubClassesNestedInput
  }

  export type UserSubClassUncheckedUpdateInput = {
    userId?: StringFieldUpdateOperationsInput | string
    subClassId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassCreateManyInput = {
    id?: string
    userId: string
    subClassId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserSubClassUpdateManyMutationInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassUncheckedUpdateManyInput = {
    userId?: StringFieldUpdateOperationsInput | string
    subClassId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaidAmountCreateInput = {
    id?: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutPaidAmountsInput
    subClass: SubClassCreateNestedOneWithoutPaidAmountsInput
  }

  export type PaidAmountUncheckedCreateInput = {
    id?: string
    userId: string
    subClassId: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaidAmountUpdateInput = {
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPaidAmountsNestedInput
    subClass?: SubClassUpdateOneRequiredWithoutPaidAmountsNestedInput
  }

  export type PaidAmountUncheckedUpdateInput = {
    userId?: StringFieldUpdateOperationsInput | string
    subClassId?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaidAmountCreateManyInput = {
    id?: string
    userId: string
    subClassId: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaidAmountUpdateManyMutationInput = {
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaidAmountUncheckedUpdateManyInput = {
    userId?: StringFieldUpdateOperationsInput | string
    subClassId?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AdminCreateInput = {
    id?: string
    name: string
    phone: string
    email: string
    role?: $Enums.Role
    password: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AdminUncheckedCreateInput = {
    id?: string
    name: string
    phone: string
    email: string
    role?: $Enums.Role
    password: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AdminUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AdminUncheckedUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AdminCreateManyInput = {
    id?: string
    name: string
    phone: string
    email: string
    role?: $Enums.Role
    password: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type AdminUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type AdminUncheckedUpdateManyInput = {
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type PaidAmountListRelationFilter = {
    every?: PaidAmountWhereInput
    some?: PaidAmountWhereInput
    none?: PaidAmountWhereInput
  }

  export type UserSubClassListRelationFilter = {
    every?: UserSubClassWhereInput
    some?: UserSubClassWhereInput
    none?: UserSubClassWhereInput
  }

  export type PaidAmountOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserSubClassOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    nationalCode?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    motherName?: SortOrder
    fatherName?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    address?: SortOrder
    city?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    nationalCode?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    motherName?: SortOrder
    fatherName?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    address?: SortOrder
    city?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    nationalCode?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    motherName?: SortOrder
    fatherName?: SortOrder
    birthDate?: SortOrder
    gender?: SortOrder
    address?: SortOrder
    city?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type SubClassListRelationFilter = {
    every?: SubClassWhereInput
    some?: SubClassWhereInput
    none?: SubClassWhereInput
  }

  export type SubClassOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ClassCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    subClassCount?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ClassAvgOrderByAggregateInput = {
    subClassCount?: SortOrder
  }

  export type ClassMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    subClassCount?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ClassMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    subClassCount?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ClassSumOrderByAggregateInput = {
    subClassCount?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type EnumDayFilter<$PrismaModel = never> = {
    equals?: $Enums.Day | EnumDayFieldRefInput<$PrismaModel>
    in?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    notIn?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    not?: NestedEnumDayFilter<$PrismaModel> | $Enums.Day
  }

  export type ClassScalarRelationFilter = {
    is?: ClassWhereInput
    isNot?: ClassWhereInput
  }

  export type SubClassCountOrderByAggregateInput = {
    id?: SortOrder
    classId?: SortOrder
    name?: SortOrder
    totalAmount?: SortOrder
    teacher?: SortOrder
    day?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SubClassAvgOrderByAggregateInput = {
    totalAmount?: SortOrder
  }

  export type SubClassMaxOrderByAggregateInput = {
    id?: SortOrder
    classId?: SortOrder
    name?: SortOrder
    totalAmount?: SortOrder
    teacher?: SortOrder
    day?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SubClassMinOrderByAggregateInput = {
    id?: SortOrder
    classId?: SortOrder
    name?: SortOrder
    totalAmount?: SortOrder
    teacher?: SortOrder
    day?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SubClassSumOrderByAggregateInput = {
    totalAmount?: SortOrder
  }

  export type EnumDayWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Day | EnumDayFieldRefInput<$PrismaModel>
    in?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    notIn?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    not?: NestedEnumDayWithAggregatesFilter<$PrismaModel> | $Enums.Day
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDayFilter<$PrismaModel>
    _max?: NestedEnumDayFilter<$PrismaModel>
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type SubClassScalarRelationFilter = {
    is?: SubClassWhereInput
    isNot?: SubClassWhereInput
  }

  export type UserSubClassCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserSubClassMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserSubClassMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EnumPayStatusNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.PayStatus | EnumPayStatusFieldRefInput<$PrismaModel> | null
    in?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPayStatusNullableFilter<$PrismaModel> | $Enums.PayStatus | null
    isSet?: boolean
  }

  export type PaidAmountCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    price?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaidAmountAvgOrderByAggregateInput = {
    price?: SortOrder
  }

  export type PaidAmountMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    price?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaidAmountMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    subClassId?: SortOrder
    price?: SortOrder
    status?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PaidAmountSumOrderByAggregateInput = {
    price?: SortOrder
  }

  export type EnumPayStatusNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PayStatus | EnumPayStatusFieldRefInput<$PrismaModel> | null
    in?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPayStatusNullableWithAggregatesFilter<$PrismaModel> | $Enums.PayStatus | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumPayStatusNullableFilter<$PrismaModel>
    _max?: NestedEnumPayStatusNullableFilter<$PrismaModel>
    isSet?: boolean
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type AdminCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    role?: SortOrder
    password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AdminMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    role?: SortOrder
    password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type AdminMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    phone?: SortOrder
    email?: SortOrder
    role?: SortOrder
    password?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type PaidAmountCreateNestedManyWithoutUserInput = {
    create?: XOR<PaidAmountCreateWithoutUserInput, PaidAmountUncheckedCreateWithoutUserInput> | PaidAmountCreateWithoutUserInput[] | PaidAmountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutUserInput | PaidAmountCreateOrConnectWithoutUserInput[]
    createMany?: PaidAmountCreateManyUserInputEnvelope
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
  }

  export type UserSubClassCreateNestedManyWithoutUserInput = {
    create?: XOR<UserSubClassCreateWithoutUserInput, UserSubClassUncheckedCreateWithoutUserInput> | UserSubClassCreateWithoutUserInput[] | UserSubClassUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutUserInput | UserSubClassCreateOrConnectWithoutUserInput[]
    createMany?: UserSubClassCreateManyUserInputEnvelope
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
  }

  export type PaidAmountUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<PaidAmountCreateWithoutUserInput, PaidAmountUncheckedCreateWithoutUserInput> | PaidAmountCreateWithoutUserInput[] | PaidAmountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutUserInput | PaidAmountCreateOrConnectWithoutUserInput[]
    createMany?: PaidAmountCreateManyUserInputEnvelope
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
  }

  export type UserSubClassUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<UserSubClassCreateWithoutUserInput, UserSubClassUncheckedCreateWithoutUserInput> | UserSubClassCreateWithoutUserInput[] | UserSubClassUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutUserInput | UserSubClassCreateOrConnectWithoutUserInput[]
    createMany?: UserSubClassCreateManyUserInputEnvelope
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type PaidAmountUpdateManyWithoutUserNestedInput = {
    create?: XOR<PaidAmountCreateWithoutUserInput, PaidAmountUncheckedCreateWithoutUserInput> | PaidAmountCreateWithoutUserInput[] | PaidAmountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutUserInput | PaidAmountCreateOrConnectWithoutUserInput[]
    upsert?: PaidAmountUpsertWithWhereUniqueWithoutUserInput | PaidAmountUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PaidAmountCreateManyUserInputEnvelope
    set?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    disconnect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    delete?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    update?: PaidAmountUpdateWithWhereUniqueWithoutUserInput | PaidAmountUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PaidAmountUpdateManyWithWhereWithoutUserInput | PaidAmountUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PaidAmountScalarWhereInput | PaidAmountScalarWhereInput[]
  }

  export type UserSubClassUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserSubClassCreateWithoutUserInput, UserSubClassUncheckedCreateWithoutUserInput> | UserSubClassCreateWithoutUserInput[] | UserSubClassUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutUserInput | UserSubClassCreateOrConnectWithoutUserInput[]
    upsert?: UserSubClassUpsertWithWhereUniqueWithoutUserInput | UserSubClassUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserSubClassCreateManyUserInputEnvelope
    set?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    disconnect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    delete?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    update?: UserSubClassUpdateWithWhereUniqueWithoutUserInput | UserSubClassUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserSubClassUpdateManyWithWhereWithoutUserInput | UserSubClassUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserSubClassScalarWhereInput | UserSubClassScalarWhereInput[]
  }

  export type PaidAmountUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<PaidAmountCreateWithoutUserInput, PaidAmountUncheckedCreateWithoutUserInput> | PaidAmountCreateWithoutUserInput[] | PaidAmountUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutUserInput | PaidAmountCreateOrConnectWithoutUserInput[]
    upsert?: PaidAmountUpsertWithWhereUniqueWithoutUserInput | PaidAmountUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PaidAmountCreateManyUserInputEnvelope
    set?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    disconnect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    delete?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    update?: PaidAmountUpdateWithWhereUniqueWithoutUserInput | PaidAmountUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PaidAmountUpdateManyWithWhereWithoutUserInput | PaidAmountUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PaidAmountScalarWhereInput | PaidAmountScalarWhereInput[]
  }

  export type UserSubClassUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<UserSubClassCreateWithoutUserInput, UserSubClassUncheckedCreateWithoutUserInput> | UserSubClassCreateWithoutUserInput[] | UserSubClassUncheckedCreateWithoutUserInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutUserInput | UserSubClassCreateOrConnectWithoutUserInput[]
    upsert?: UserSubClassUpsertWithWhereUniqueWithoutUserInput | UserSubClassUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: UserSubClassCreateManyUserInputEnvelope
    set?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    disconnect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    delete?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    update?: UserSubClassUpdateWithWhereUniqueWithoutUserInput | UserSubClassUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: UserSubClassUpdateManyWithWhereWithoutUserInput | UserSubClassUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: UserSubClassScalarWhereInput | UserSubClassScalarWhereInput[]
  }

  export type SubClassCreateNestedManyWithoutClassInput = {
    create?: XOR<SubClassCreateWithoutClassInput, SubClassUncheckedCreateWithoutClassInput> | SubClassCreateWithoutClassInput[] | SubClassUncheckedCreateWithoutClassInput[]
    connectOrCreate?: SubClassCreateOrConnectWithoutClassInput | SubClassCreateOrConnectWithoutClassInput[]
    createMany?: SubClassCreateManyClassInputEnvelope
    connect?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
  }

  export type SubClassUncheckedCreateNestedManyWithoutClassInput = {
    create?: XOR<SubClassCreateWithoutClassInput, SubClassUncheckedCreateWithoutClassInput> | SubClassCreateWithoutClassInput[] | SubClassUncheckedCreateWithoutClassInput[]
    connectOrCreate?: SubClassCreateOrConnectWithoutClassInput | SubClassCreateOrConnectWithoutClassInput[]
    createMany?: SubClassCreateManyClassInputEnvelope
    connect?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type SubClassUpdateManyWithoutClassNestedInput = {
    create?: XOR<SubClassCreateWithoutClassInput, SubClassUncheckedCreateWithoutClassInput> | SubClassCreateWithoutClassInput[] | SubClassUncheckedCreateWithoutClassInput[]
    connectOrCreate?: SubClassCreateOrConnectWithoutClassInput | SubClassCreateOrConnectWithoutClassInput[]
    upsert?: SubClassUpsertWithWhereUniqueWithoutClassInput | SubClassUpsertWithWhereUniqueWithoutClassInput[]
    createMany?: SubClassCreateManyClassInputEnvelope
    set?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    disconnect?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    delete?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    connect?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    update?: SubClassUpdateWithWhereUniqueWithoutClassInput | SubClassUpdateWithWhereUniqueWithoutClassInput[]
    updateMany?: SubClassUpdateManyWithWhereWithoutClassInput | SubClassUpdateManyWithWhereWithoutClassInput[]
    deleteMany?: SubClassScalarWhereInput | SubClassScalarWhereInput[]
  }

  export type SubClassUncheckedUpdateManyWithoutClassNestedInput = {
    create?: XOR<SubClassCreateWithoutClassInput, SubClassUncheckedCreateWithoutClassInput> | SubClassCreateWithoutClassInput[] | SubClassUncheckedCreateWithoutClassInput[]
    connectOrCreate?: SubClassCreateOrConnectWithoutClassInput | SubClassCreateOrConnectWithoutClassInput[]
    upsert?: SubClassUpsertWithWhereUniqueWithoutClassInput | SubClassUpsertWithWhereUniqueWithoutClassInput[]
    createMany?: SubClassCreateManyClassInputEnvelope
    set?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    disconnect?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    delete?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    connect?: SubClassWhereUniqueInput | SubClassWhereUniqueInput[]
    update?: SubClassUpdateWithWhereUniqueWithoutClassInput | SubClassUpdateWithWhereUniqueWithoutClassInput[]
    updateMany?: SubClassUpdateManyWithWhereWithoutClassInput | SubClassUpdateManyWithWhereWithoutClassInput[]
    deleteMany?: SubClassScalarWhereInput | SubClassScalarWhereInput[]
  }

  export type ClassCreateNestedOneWithoutSubClassInput = {
    create?: XOR<ClassCreateWithoutSubClassInput, ClassUncheckedCreateWithoutSubClassInput>
    connectOrCreate?: ClassCreateOrConnectWithoutSubClassInput
    connect?: ClassWhereUniqueInput
  }

  export type UserSubClassCreateNestedManyWithoutSubClassInput = {
    create?: XOR<UserSubClassCreateWithoutSubClassInput, UserSubClassUncheckedCreateWithoutSubClassInput> | UserSubClassCreateWithoutSubClassInput[] | UserSubClassUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutSubClassInput | UserSubClassCreateOrConnectWithoutSubClassInput[]
    createMany?: UserSubClassCreateManySubClassInputEnvelope
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
  }

  export type PaidAmountCreateNestedManyWithoutSubClassInput = {
    create?: XOR<PaidAmountCreateWithoutSubClassInput, PaidAmountUncheckedCreateWithoutSubClassInput> | PaidAmountCreateWithoutSubClassInput[] | PaidAmountUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutSubClassInput | PaidAmountCreateOrConnectWithoutSubClassInput[]
    createMany?: PaidAmountCreateManySubClassInputEnvelope
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
  }

  export type UserSubClassUncheckedCreateNestedManyWithoutSubClassInput = {
    create?: XOR<UserSubClassCreateWithoutSubClassInput, UserSubClassUncheckedCreateWithoutSubClassInput> | UserSubClassCreateWithoutSubClassInput[] | UserSubClassUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutSubClassInput | UserSubClassCreateOrConnectWithoutSubClassInput[]
    createMany?: UserSubClassCreateManySubClassInputEnvelope
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
  }

  export type PaidAmountUncheckedCreateNestedManyWithoutSubClassInput = {
    create?: XOR<PaidAmountCreateWithoutSubClassInput, PaidAmountUncheckedCreateWithoutSubClassInput> | PaidAmountCreateWithoutSubClassInput[] | PaidAmountUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutSubClassInput | PaidAmountCreateOrConnectWithoutSubClassInput[]
    createMany?: PaidAmountCreateManySubClassInputEnvelope
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
  }

  export type EnumDayFieldUpdateOperationsInput = {
    set?: $Enums.Day
  }

  export type ClassUpdateOneRequiredWithoutSubClassNestedInput = {
    create?: XOR<ClassCreateWithoutSubClassInput, ClassUncheckedCreateWithoutSubClassInput>
    connectOrCreate?: ClassCreateOrConnectWithoutSubClassInput
    upsert?: ClassUpsertWithoutSubClassInput
    connect?: ClassWhereUniqueInput
    update?: XOR<XOR<ClassUpdateToOneWithWhereWithoutSubClassInput, ClassUpdateWithoutSubClassInput>, ClassUncheckedUpdateWithoutSubClassInput>
  }

  export type UserSubClassUpdateManyWithoutSubClassNestedInput = {
    create?: XOR<UserSubClassCreateWithoutSubClassInput, UserSubClassUncheckedCreateWithoutSubClassInput> | UserSubClassCreateWithoutSubClassInput[] | UserSubClassUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutSubClassInput | UserSubClassCreateOrConnectWithoutSubClassInput[]
    upsert?: UserSubClassUpsertWithWhereUniqueWithoutSubClassInput | UserSubClassUpsertWithWhereUniqueWithoutSubClassInput[]
    createMany?: UserSubClassCreateManySubClassInputEnvelope
    set?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    disconnect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    delete?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    update?: UserSubClassUpdateWithWhereUniqueWithoutSubClassInput | UserSubClassUpdateWithWhereUniqueWithoutSubClassInput[]
    updateMany?: UserSubClassUpdateManyWithWhereWithoutSubClassInput | UserSubClassUpdateManyWithWhereWithoutSubClassInput[]
    deleteMany?: UserSubClassScalarWhereInput | UserSubClassScalarWhereInput[]
  }

  export type PaidAmountUpdateManyWithoutSubClassNestedInput = {
    create?: XOR<PaidAmountCreateWithoutSubClassInput, PaidAmountUncheckedCreateWithoutSubClassInput> | PaidAmountCreateWithoutSubClassInput[] | PaidAmountUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutSubClassInput | PaidAmountCreateOrConnectWithoutSubClassInput[]
    upsert?: PaidAmountUpsertWithWhereUniqueWithoutSubClassInput | PaidAmountUpsertWithWhereUniqueWithoutSubClassInput[]
    createMany?: PaidAmountCreateManySubClassInputEnvelope
    set?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    disconnect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    delete?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    update?: PaidAmountUpdateWithWhereUniqueWithoutSubClassInput | PaidAmountUpdateWithWhereUniqueWithoutSubClassInput[]
    updateMany?: PaidAmountUpdateManyWithWhereWithoutSubClassInput | PaidAmountUpdateManyWithWhereWithoutSubClassInput[]
    deleteMany?: PaidAmountScalarWhereInput | PaidAmountScalarWhereInput[]
  }

  export type UserSubClassUncheckedUpdateManyWithoutSubClassNestedInput = {
    create?: XOR<UserSubClassCreateWithoutSubClassInput, UserSubClassUncheckedCreateWithoutSubClassInput> | UserSubClassCreateWithoutSubClassInput[] | UserSubClassUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: UserSubClassCreateOrConnectWithoutSubClassInput | UserSubClassCreateOrConnectWithoutSubClassInput[]
    upsert?: UserSubClassUpsertWithWhereUniqueWithoutSubClassInput | UserSubClassUpsertWithWhereUniqueWithoutSubClassInput[]
    createMany?: UserSubClassCreateManySubClassInputEnvelope
    set?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    disconnect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    delete?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    connect?: UserSubClassWhereUniqueInput | UserSubClassWhereUniqueInput[]
    update?: UserSubClassUpdateWithWhereUniqueWithoutSubClassInput | UserSubClassUpdateWithWhereUniqueWithoutSubClassInput[]
    updateMany?: UserSubClassUpdateManyWithWhereWithoutSubClassInput | UserSubClassUpdateManyWithWhereWithoutSubClassInput[]
    deleteMany?: UserSubClassScalarWhereInput | UserSubClassScalarWhereInput[]
  }

  export type PaidAmountUncheckedUpdateManyWithoutSubClassNestedInput = {
    create?: XOR<PaidAmountCreateWithoutSubClassInput, PaidAmountUncheckedCreateWithoutSubClassInput> | PaidAmountCreateWithoutSubClassInput[] | PaidAmountUncheckedCreateWithoutSubClassInput[]
    connectOrCreate?: PaidAmountCreateOrConnectWithoutSubClassInput | PaidAmountCreateOrConnectWithoutSubClassInput[]
    upsert?: PaidAmountUpsertWithWhereUniqueWithoutSubClassInput | PaidAmountUpsertWithWhereUniqueWithoutSubClassInput[]
    createMany?: PaidAmountCreateManySubClassInputEnvelope
    set?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    disconnect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    delete?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    connect?: PaidAmountWhereUniqueInput | PaidAmountWhereUniqueInput[]
    update?: PaidAmountUpdateWithWhereUniqueWithoutSubClassInput | PaidAmountUpdateWithWhereUniqueWithoutSubClassInput[]
    updateMany?: PaidAmountUpdateManyWithWhereWithoutSubClassInput | PaidAmountUpdateManyWithWhereWithoutSubClassInput[]
    deleteMany?: PaidAmountScalarWhereInput | PaidAmountScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutUserSubClassesInput = {
    create?: XOR<UserCreateWithoutUserSubClassesInput, UserUncheckedCreateWithoutUserSubClassesInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserSubClassesInput
    connect?: UserWhereUniqueInput
  }

  export type SubClassCreateNestedOneWithoutUserSubClassesInput = {
    create?: XOR<SubClassCreateWithoutUserSubClassesInput, SubClassUncheckedCreateWithoutUserSubClassesInput>
    connectOrCreate?: SubClassCreateOrConnectWithoutUserSubClassesInput
    connect?: SubClassWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutUserSubClassesNestedInput = {
    create?: XOR<UserCreateWithoutUserSubClassesInput, UserUncheckedCreateWithoutUserSubClassesInput>
    connectOrCreate?: UserCreateOrConnectWithoutUserSubClassesInput
    upsert?: UserUpsertWithoutUserSubClassesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutUserSubClassesInput, UserUpdateWithoutUserSubClassesInput>, UserUncheckedUpdateWithoutUserSubClassesInput>
  }

  export type SubClassUpdateOneRequiredWithoutUserSubClassesNestedInput = {
    create?: XOR<SubClassCreateWithoutUserSubClassesInput, SubClassUncheckedCreateWithoutUserSubClassesInput>
    connectOrCreate?: SubClassCreateOrConnectWithoutUserSubClassesInput
    upsert?: SubClassUpsertWithoutUserSubClassesInput
    connect?: SubClassWhereUniqueInput
    update?: XOR<XOR<SubClassUpdateToOneWithWhereWithoutUserSubClassesInput, SubClassUpdateWithoutUserSubClassesInput>, SubClassUncheckedUpdateWithoutUserSubClassesInput>
  }

  export type UserCreateNestedOneWithoutPaidAmountsInput = {
    create?: XOR<UserCreateWithoutPaidAmountsInput, UserUncheckedCreateWithoutPaidAmountsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPaidAmountsInput
    connect?: UserWhereUniqueInput
  }

  export type SubClassCreateNestedOneWithoutPaidAmountsInput = {
    create?: XOR<SubClassCreateWithoutPaidAmountsInput, SubClassUncheckedCreateWithoutPaidAmountsInput>
    connectOrCreate?: SubClassCreateOrConnectWithoutPaidAmountsInput
    connect?: SubClassWhereUniqueInput
  }

  export type NullableEnumPayStatusFieldUpdateOperationsInput = {
    set?: $Enums.PayStatus | null
    unset?: boolean
  }

  export type UserUpdateOneRequiredWithoutPaidAmountsNestedInput = {
    create?: XOR<UserCreateWithoutPaidAmountsInput, UserUncheckedCreateWithoutPaidAmountsInput>
    connectOrCreate?: UserCreateOrConnectWithoutPaidAmountsInput
    upsert?: UserUpsertWithoutPaidAmountsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutPaidAmountsInput, UserUpdateWithoutPaidAmountsInput>, UserUncheckedUpdateWithoutPaidAmountsInput>
  }

  export type SubClassUpdateOneRequiredWithoutPaidAmountsNestedInput = {
    create?: XOR<SubClassCreateWithoutPaidAmountsInput, SubClassUncheckedCreateWithoutPaidAmountsInput>
    connectOrCreate?: SubClassCreateOrConnectWithoutPaidAmountsInput
    upsert?: SubClassUpsertWithoutPaidAmountsInput
    connect?: SubClassWhereUniqueInput
    update?: XOR<XOR<SubClassUpdateToOneWithWhereWithoutPaidAmountsInput, SubClassUpdateWithoutPaidAmountsInput>, SubClassUncheckedUpdateWithoutPaidAmountsInput>
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedEnumDayFilter<$PrismaModel = never> = {
    equals?: $Enums.Day | EnumDayFieldRefInput<$PrismaModel>
    in?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    notIn?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    not?: NestedEnumDayFilter<$PrismaModel> | $Enums.Day
  }

  export type NestedEnumDayWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Day | EnumDayFieldRefInput<$PrismaModel>
    in?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    notIn?: $Enums.Day[] | ListEnumDayFieldRefInput<$PrismaModel>
    not?: NestedEnumDayWithAggregatesFilter<$PrismaModel> | $Enums.Day
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDayFilter<$PrismaModel>
    _max?: NestedEnumDayFilter<$PrismaModel>
  }

  export type NestedEnumPayStatusNullableFilter<$PrismaModel = never> = {
    equals?: $Enums.PayStatus | EnumPayStatusFieldRefInput<$PrismaModel> | null
    in?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPayStatusNullableFilter<$PrismaModel> | $Enums.PayStatus | null
    isSet?: boolean
  }

  export type NestedEnumPayStatusNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PayStatus | EnumPayStatusFieldRefInput<$PrismaModel> | null
    in?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    notIn?: $Enums.PayStatus[] | ListEnumPayStatusFieldRefInput<$PrismaModel> | null
    not?: NestedEnumPayStatusNullableWithAggregatesFilter<$PrismaModel> | $Enums.PayStatus | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedEnumPayStatusNullableFilter<$PrismaModel>
    _max?: NestedEnumPayStatusNullableFilter<$PrismaModel>
    isSet?: boolean
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
    isSet?: boolean
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type PaidAmountCreateWithoutUserInput = {
    id?: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
    subClass: SubClassCreateNestedOneWithoutPaidAmountsInput
  }

  export type PaidAmountUncheckedCreateWithoutUserInput = {
    id?: string
    subClassId: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaidAmountCreateOrConnectWithoutUserInput = {
    where: PaidAmountWhereUniqueInput
    create: XOR<PaidAmountCreateWithoutUserInput, PaidAmountUncheckedCreateWithoutUserInput>
  }

  export type PaidAmountCreateManyUserInputEnvelope = {
    data: PaidAmountCreateManyUserInput | PaidAmountCreateManyUserInput[]
  }

  export type UserSubClassCreateWithoutUserInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    subClass: SubClassCreateNestedOneWithoutUserSubClassesInput
  }

  export type UserSubClassUncheckedCreateWithoutUserInput = {
    id?: string
    subClassId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserSubClassCreateOrConnectWithoutUserInput = {
    where: UserSubClassWhereUniqueInput
    create: XOR<UserSubClassCreateWithoutUserInput, UserSubClassUncheckedCreateWithoutUserInput>
  }

  export type UserSubClassCreateManyUserInputEnvelope = {
    data: UserSubClassCreateManyUserInput | UserSubClassCreateManyUserInput[]
  }

  export type PaidAmountUpsertWithWhereUniqueWithoutUserInput = {
    where: PaidAmountWhereUniqueInput
    update: XOR<PaidAmountUpdateWithoutUserInput, PaidAmountUncheckedUpdateWithoutUserInput>
    create: XOR<PaidAmountCreateWithoutUserInput, PaidAmountUncheckedCreateWithoutUserInput>
  }

  export type PaidAmountUpdateWithWhereUniqueWithoutUserInput = {
    where: PaidAmountWhereUniqueInput
    data: XOR<PaidAmountUpdateWithoutUserInput, PaidAmountUncheckedUpdateWithoutUserInput>
  }

  export type PaidAmountUpdateManyWithWhereWithoutUserInput = {
    where: PaidAmountScalarWhereInput
    data: XOR<PaidAmountUpdateManyMutationInput, PaidAmountUncheckedUpdateManyWithoutUserInput>
  }

  export type PaidAmountScalarWhereInput = {
    AND?: PaidAmountScalarWhereInput | PaidAmountScalarWhereInput[]
    OR?: PaidAmountScalarWhereInput[]
    NOT?: PaidAmountScalarWhereInput | PaidAmountScalarWhereInput[]
    id?: StringFilter<"PaidAmount"> | string
    userId?: StringFilter<"PaidAmount"> | string
    subClassId?: StringFilter<"PaidAmount"> | string
    price?: IntFilter<"PaidAmount"> | number
    status?: EnumPayStatusNullableFilter<"PaidAmount"> | $Enums.PayStatus | null
    createdAt?: DateTimeFilter<"PaidAmount"> | Date | string
    updatedAt?: DateTimeFilter<"PaidAmount"> | Date | string
  }

  export type UserSubClassUpsertWithWhereUniqueWithoutUserInput = {
    where: UserSubClassWhereUniqueInput
    update: XOR<UserSubClassUpdateWithoutUserInput, UserSubClassUncheckedUpdateWithoutUserInput>
    create: XOR<UserSubClassCreateWithoutUserInput, UserSubClassUncheckedCreateWithoutUserInput>
  }

  export type UserSubClassUpdateWithWhereUniqueWithoutUserInput = {
    where: UserSubClassWhereUniqueInput
    data: XOR<UserSubClassUpdateWithoutUserInput, UserSubClassUncheckedUpdateWithoutUserInput>
  }

  export type UserSubClassUpdateManyWithWhereWithoutUserInput = {
    where: UserSubClassScalarWhereInput
    data: XOR<UserSubClassUpdateManyMutationInput, UserSubClassUncheckedUpdateManyWithoutUserInput>
  }

  export type UserSubClassScalarWhereInput = {
    AND?: UserSubClassScalarWhereInput | UserSubClassScalarWhereInput[]
    OR?: UserSubClassScalarWhereInput[]
    NOT?: UserSubClassScalarWhereInput | UserSubClassScalarWhereInput[]
    id?: StringFilter<"UserSubClass"> | string
    userId?: StringFilter<"UserSubClass"> | string
    subClassId?: StringFilter<"UserSubClass"> | string
    createdAt?: DateTimeFilter<"UserSubClass"> | Date | string
    updatedAt?: DateTimeFilter<"UserSubClass"> | Date | string
  }

  export type SubClassCreateWithoutClassInput = {
    id?: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userSubClasses?: UserSubClassCreateNestedManyWithoutSubClassInput
    paidAmounts?: PaidAmountCreateNestedManyWithoutSubClassInput
  }

  export type SubClassUncheckedCreateWithoutClassInput = {
    id?: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userSubClasses?: UserSubClassUncheckedCreateNestedManyWithoutSubClassInput
    paidAmounts?: PaidAmountUncheckedCreateNestedManyWithoutSubClassInput
  }

  export type SubClassCreateOrConnectWithoutClassInput = {
    where: SubClassWhereUniqueInput
    create: XOR<SubClassCreateWithoutClassInput, SubClassUncheckedCreateWithoutClassInput>
  }

  export type SubClassCreateManyClassInputEnvelope = {
    data: SubClassCreateManyClassInput | SubClassCreateManyClassInput[]
  }

  export type SubClassUpsertWithWhereUniqueWithoutClassInput = {
    where: SubClassWhereUniqueInput
    update: XOR<SubClassUpdateWithoutClassInput, SubClassUncheckedUpdateWithoutClassInput>
    create: XOR<SubClassCreateWithoutClassInput, SubClassUncheckedCreateWithoutClassInput>
  }

  export type SubClassUpdateWithWhereUniqueWithoutClassInput = {
    where: SubClassWhereUniqueInput
    data: XOR<SubClassUpdateWithoutClassInput, SubClassUncheckedUpdateWithoutClassInput>
  }

  export type SubClassUpdateManyWithWhereWithoutClassInput = {
    where: SubClassScalarWhereInput
    data: XOR<SubClassUpdateManyMutationInput, SubClassUncheckedUpdateManyWithoutClassInput>
  }

  export type SubClassScalarWhereInput = {
    AND?: SubClassScalarWhereInput | SubClassScalarWhereInput[]
    OR?: SubClassScalarWhereInput[]
    NOT?: SubClassScalarWhereInput | SubClassScalarWhereInput[]
    id?: StringFilter<"SubClass"> | string
    classId?: StringFilter<"SubClass"> | string
    name?: StringFilter<"SubClass"> | string
    totalAmount?: IntFilter<"SubClass"> | number
    teacher?: StringFilter<"SubClass"> | string
    day?: EnumDayFilter<"SubClass"> | $Enums.Day
    startTime?: StringFilter<"SubClass"> | string
    endTime?: StringFilter<"SubClass"> | string
    createdAt?: DateTimeFilter<"SubClass"> | Date | string
    updatedAt?: DateTimeFilter<"SubClass"> | Date | string
  }

  export type ClassCreateWithoutSubClassInput = {
    id?: string
    name: string
    subClassCount: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ClassUncheckedCreateWithoutSubClassInput = {
    id?: string
    name: string
    subClassCount: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ClassCreateOrConnectWithoutSubClassInput = {
    where: ClassWhereUniqueInput
    create: XOR<ClassCreateWithoutSubClassInput, ClassUncheckedCreateWithoutSubClassInput>
  }

  export type UserSubClassCreateWithoutSubClassInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutUserSubClassesInput
  }

  export type UserSubClassUncheckedCreateWithoutSubClassInput = {
    id?: string
    userId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserSubClassCreateOrConnectWithoutSubClassInput = {
    where: UserSubClassWhereUniqueInput
    create: XOR<UserSubClassCreateWithoutSubClassInput, UserSubClassUncheckedCreateWithoutSubClassInput>
  }

  export type UserSubClassCreateManySubClassInputEnvelope = {
    data: UserSubClassCreateManySubClassInput | UserSubClassCreateManySubClassInput[]
  }

  export type PaidAmountCreateWithoutSubClassInput = {
    id?: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutPaidAmountsInput
  }

  export type PaidAmountUncheckedCreateWithoutSubClassInput = {
    id?: string
    userId: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaidAmountCreateOrConnectWithoutSubClassInput = {
    where: PaidAmountWhereUniqueInput
    create: XOR<PaidAmountCreateWithoutSubClassInput, PaidAmountUncheckedCreateWithoutSubClassInput>
  }

  export type PaidAmountCreateManySubClassInputEnvelope = {
    data: PaidAmountCreateManySubClassInput | PaidAmountCreateManySubClassInput[]
  }

  export type ClassUpsertWithoutSubClassInput = {
    update: XOR<ClassUpdateWithoutSubClassInput, ClassUncheckedUpdateWithoutSubClassInput>
    create: XOR<ClassCreateWithoutSubClassInput, ClassUncheckedCreateWithoutSubClassInput>
    where?: ClassWhereInput
  }

  export type ClassUpdateToOneWithWhereWithoutSubClassInput = {
    where?: ClassWhereInput
    data: XOR<ClassUpdateWithoutSubClassInput, ClassUncheckedUpdateWithoutSubClassInput>
  }

  export type ClassUpdateWithoutSubClassInput = {
    name?: StringFieldUpdateOperationsInput | string
    subClassCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ClassUncheckedUpdateWithoutSubClassInput = {
    name?: StringFieldUpdateOperationsInput | string
    subClassCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassUpsertWithWhereUniqueWithoutSubClassInput = {
    where: UserSubClassWhereUniqueInput
    update: XOR<UserSubClassUpdateWithoutSubClassInput, UserSubClassUncheckedUpdateWithoutSubClassInput>
    create: XOR<UserSubClassCreateWithoutSubClassInput, UserSubClassUncheckedCreateWithoutSubClassInput>
  }

  export type UserSubClassUpdateWithWhereUniqueWithoutSubClassInput = {
    where: UserSubClassWhereUniqueInput
    data: XOR<UserSubClassUpdateWithoutSubClassInput, UserSubClassUncheckedUpdateWithoutSubClassInput>
  }

  export type UserSubClassUpdateManyWithWhereWithoutSubClassInput = {
    where: UserSubClassScalarWhereInput
    data: XOR<UserSubClassUpdateManyMutationInput, UserSubClassUncheckedUpdateManyWithoutSubClassInput>
  }

  export type PaidAmountUpsertWithWhereUniqueWithoutSubClassInput = {
    where: PaidAmountWhereUniqueInput
    update: XOR<PaidAmountUpdateWithoutSubClassInput, PaidAmountUncheckedUpdateWithoutSubClassInput>
    create: XOR<PaidAmountCreateWithoutSubClassInput, PaidAmountUncheckedCreateWithoutSubClassInput>
  }

  export type PaidAmountUpdateWithWhereUniqueWithoutSubClassInput = {
    where: PaidAmountWhereUniqueInput
    data: XOR<PaidAmountUpdateWithoutSubClassInput, PaidAmountUncheckedUpdateWithoutSubClassInput>
  }

  export type PaidAmountUpdateManyWithWhereWithoutSubClassInput = {
    where: PaidAmountScalarWhereInput
    data: XOR<PaidAmountUpdateManyMutationInput, PaidAmountUncheckedUpdateManyWithoutSubClassInput>
  }

  export type UserCreateWithoutUserSubClassesInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paidAmounts?: PaidAmountCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutUserSubClassesInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paidAmounts?: PaidAmountUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutUserSubClassesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutUserSubClassesInput, UserUncheckedCreateWithoutUserSubClassesInput>
  }

  export type SubClassCreateWithoutUserSubClassesInput = {
    id?: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    class: ClassCreateNestedOneWithoutSubClassInput
    paidAmounts?: PaidAmountCreateNestedManyWithoutSubClassInput
  }

  export type SubClassUncheckedCreateWithoutUserSubClassesInput = {
    id?: string
    classId: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    paidAmounts?: PaidAmountUncheckedCreateNestedManyWithoutSubClassInput
  }

  export type SubClassCreateOrConnectWithoutUserSubClassesInput = {
    where: SubClassWhereUniqueInput
    create: XOR<SubClassCreateWithoutUserSubClassesInput, SubClassUncheckedCreateWithoutUserSubClassesInput>
  }

  export type UserUpsertWithoutUserSubClassesInput = {
    update: XOR<UserUpdateWithoutUserSubClassesInput, UserUncheckedUpdateWithoutUserSubClassesInput>
    create: XOR<UserCreateWithoutUserSubClassesInput, UserUncheckedCreateWithoutUserSubClassesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutUserSubClassesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutUserSubClassesInput, UserUncheckedUpdateWithoutUserSubClassesInput>
  }

  export type UserUpdateWithoutUserSubClassesInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paidAmounts?: PaidAmountUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutUserSubClassesInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paidAmounts?: PaidAmountUncheckedUpdateManyWithoutUserNestedInput
  }

  export type SubClassUpsertWithoutUserSubClassesInput = {
    update: XOR<SubClassUpdateWithoutUserSubClassesInput, SubClassUncheckedUpdateWithoutUserSubClassesInput>
    create: XOR<SubClassCreateWithoutUserSubClassesInput, SubClassUncheckedCreateWithoutUserSubClassesInput>
    where?: SubClassWhereInput
  }

  export type SubClassUpdateToOneWithWhereWithoutUserSubClassesInput = {
    where?: SubClassWhereInput
    data: XOR<SubClassUpdateWithoutUserSubClassesInput, SubClassUncheckedUpdateWithoutUserSubClassesInput>
  }

  export type SubClassUpdateWithoutUserSubClassesInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    class?: ClassUpdateOneRequiredWithoutSubClassNestedInput
    paidAmounts?: PaidAmountUpdateManyWithoutSubClassNestedInput
  }

  export type SubClassUncheckedUpdateWithoutUserSubClassesInput = {
    classId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    paidAmounts?: PaidAmountUncheckedUpdateManyWithoutSubClassNestedInput
  }

  export type UserCreateWithoutPaidAmountsInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userSubClasses?: UserSubClassCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutPaidAmountsInput = {
    id?: string
    nationalCode: string
    name: string
    phone: string
    motherName: string
    fatherName: string
    birthDate: Date | string
    gender: string
    address: string
    city: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userSubClasses?: UserSubClassUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutPaidAmountsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutPaidAmountsInput, UserUncheckedCreateWithoutPaidAmountsInput>
  }

  export type SubClassCreateWithoutPaidAmountsInput = {
    id?: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    class: ClassCreateNestedOneWithoutSubClassInput
    userSubClasses?: UserSubClassCreateNestedManyWithoutSubClassInput
  }

  export type SubClassUncheckedCreateWithoutPaidAmountsInput = {
    id?: string
    classId: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
    userSubClasses?: UserSubClassUncheckedCreateNestedManyWithoutSubClassInput
  }

  export type SubClassCreateOrConnectWithoutPaidAmountsInput = {
    where: SubClassWhereUniqueInput
    create: XOR<SubClassCreateWithoutPaidAmountsInput, SubClassUncheckedCreateWithoutPaidAmountsInput>
  }

  export type UserUpsertWithoutPaidAmountsInput = {
    update: XOR<UserUpdateWithoutPaidAmountsInput, UserUncheckedUpdateWithoutPaidAmountsInput>
    create: XOR<UserCreateWithoutPaidAmountsInput, UserUncheckedCreateWithoutPaidAmountsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutPaidAmountsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutPaidAmountsInput, UserUncheckedUpdateWithoutPaidAmountsInput>
  }

  export type UserUpdateWithoutPaidAmountsInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userSubClasses?: UserSubClassUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutPaidAmountsInput = {
    nationalCode?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    phone?: StringFieldUpdateOperationsInput | string
    motherName?: StringFieldUpdateOperationsInput | string
    fatherName?: StringFieldUpdateOperationsInput | string
    birthDate?: DateTimeFieldUpdateOperationsInput | Date | string
    gender?: StringFieldUpdateOperationsInput | string
    address?: StringFieldUpdateOperationsInput | string
    city?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userSubClasses?: UserSubClassUncheckedUpdateManyWithoutUserNestedInput
  }

  export type SubClassUpsertWithoutPaidAmountsInput = {
    update: XOR<SubClassUpdateWithoutPaidAmountsInput, SubClassUncheckedUpdateWithoutPaidAmountsInput>
    create: XOR<SubClassCreateWithoutPaidAmountsInput, SubClassUncheckedCreateWithoutPaidAmountsInput>
    where?: SubClassWhereInput
  }

  export type SubClassUpdateToOneWithWhereWithoutPaidAmountsInput = {
    where?: SubClassWhereInput
    data: XOR<SubClassUpdateWithoutPaidAmountsInput, SubClassUncheckedUpdateWithoutPaidAmountsInput>
  }

  export type SubClassUpdateWithoutPaidAmountsInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    class?: ClassUpdateOneRequiredWithoutSubClassNestedInput
    userSubClasses?: UserSubClassUpdateManyWithoutSubClassNestedInput
  }

  export type SubClassUncheckedUpdateWithoutPaidAmountsInput = {
    classId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userSubClasses?: UserSubClassUncheckedUpdateManyWithoutSubClassNestedInput
  }

  export type PaidAmountCreateManyUserInput = {
    id?: string
    subClassId: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserSubClassCreateManyUserInput = {
    id?: string
    subClassId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaidAmountUpdateWithoutUserInput = {
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    subClass?: SubClassUpdateOneRequiredWithoutPaidAmountsNestedInput
  }

  export type PaidAmountUncheckedUpdateWithoutUserInput = {
    subClassId?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaidAmountUncheckedUpdateManyWithoutUserInput = {
    subClassId?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassUpdateWithoutUserInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    subClass?: SubClassUpdateOneRequiredWithoutUserSubClassesNestedInput
  }

  export type UserSubClassUncheckedUpdateWithoutUserInput = {
    subClassId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassUncheckedUpdateManyWithoutUserInput = {
    subClassId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SubClassCreateManyClassInput = {
    id?: string
    name: string
    totalAmount: number
    teacher: string
    day: $Enums.Day
    startTime: string
    endTime: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SubClassUpdateWithoutClassInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userSubClasses?: UserSubClassUpdateManyWithoutSubClassNestedInput
    paidAmounts?: PaidAmountUpdateManyWithoutSubClassNestedInput
  }

  export type SubClassUncheckedUpdateWithoutClassInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    userSubClasses?: UserSubClassUncheckedUpdateManyWithoutSubClassNestedInput
    paidAmounts?: PaidAmountUncheckedUpdateManyWithoutSubClassNestedInput
  }

  export type SubClassUncheckedUpdateManyWithoutClassInput = {
    name?: StringFieldUpdateOperationsInput | string
    totalAmount?: IntFieldUpdateOperationsInput | number
    teacher?: StringFieldUpdateOperationsInput | string
    day?: EnumDayFieldUpdateOperationsInput | $Enums.Day
    startTime?: StringFieldUpdateOperationsInput | string
    endTime?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassCreateManySubClassInput = {
    id?: string
    userId: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PaidAmountCreateManySubClassInput = {
    id?: string
    userId: string
    price: number
    status?: $Enums.PayStatus | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserSubClassUpdateWithoutSubClassInput = {
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutUserSubClassesNestedInput
  }

  export type UserSubClassUncheckedUpdateWithoutSubClassInput = {
    userId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserSubClassUncheckedUpdateManyWithoutSubClassInput = {
    userId?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaidAmountUpdateWithoutSubClassInput = {
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPaidAmountsNestedInput
  }

  export type PaidAmountUncheckedUpdateWithoutSubClassInput = {
    userId?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PaidAmountUncheckedUpdateManyWithoutSubClassInput = {
    userId?: StringFieldUpdateOperationsInput | string
    price?: IntFieldUpdateOperationsInput | number
    status?: NullableEnumPayStatusFieldUpdateOperationsInput | $Enums.PayStatus | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}